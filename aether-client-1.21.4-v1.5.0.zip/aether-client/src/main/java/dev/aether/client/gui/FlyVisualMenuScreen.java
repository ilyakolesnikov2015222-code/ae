package dev.aether.client.gui;

import dev.aether.client.AetherClient;
import dev.aether.client.config.AetherConfig;
import dev.aether.client.hud.AetherHudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

public class FlyVisualMenuScreen extends Screen {

    private record ModuleItem(String name, BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {}

    private TextFieldWidget searchField;
    private TextFieldWidget friendField;
    private String statusText = "";
    private boolean showFriendsDrawer = false;

    public FlyVisualMenuScreen() {
        super(Text.literal(AetherClient.CLIENT_NAME));
    }

    @Override
    protected void init() {
        this.clearChildren();
        AetherConfig cfg = AetherConfig.get();

        int colW = 132;
        int colGap = 6;
        int totalW = colW * 5 + colGap * 4;
        int startX = Math.max(8, (this.width - totalW) / 2);
        int topY = Math.max(24, (this.height - 238) / 2);
        int colH = 228;

        // Top status pill ("Безопасный режим")
        String modeLabel = cfg.safeMode ? "Безопасный режим" : AetherClient.CLIENT_NAME + " v" + AetherClient.VERSION;
        int pillW = Math.max(120, this.textRenderer.getWidth(modeLabel) + 20);
        int pillX = this.width / 2 - pillW / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal(modeLabel), b -> {
            cfg.safeMode = !cfg.safeMode;
            AetherConfig.save();
            init();
        }).dimensions(pillX, topY - 20, pillW, 15).build());

        // Column 1: Combat
        List<ModuleItem> combatItems = List.of(
                new ModuleItem("ArmorDurability", () -> cfg.armorDurability, v -> cfg.armorDurability = v),
                new ModuleItem("HitParticles", () -> cfg.hitParticles, v -> cfg.hitParticles = v),
                new ModuleItem("TargetInfo", () -> cfg.targetInfo, v -> cfg.targetInfo = v),
                new ModuleItem("SwingVisual", () -> cfg.swingVisual, v -> cfg.swingVisual = v),
                new ModuleItem("HitFlash", () -> cfg.hitFlash, v -> cfg.hitFlash = v)
        );
        buildModuleColumn(cfg, startX, topY, colW, colH, "Combat", combatItems);

        // Column 2: Misc
        int c2 = startX + (colW + colGap);
        List<ModuleItem> miscItems = List.of(
                new ModuleItem("FriendsHighlight", () -> cfg.friendsHighlight, v -> cfg.friendsHighlight = v),
                new ModuleItem("NearbyRadar", () -> cfg.nearbyRadar, v -> cfg.nearbyRadar = v),
                new ModuleItem("WorldClock", () -> cfg.worldClock, v -> cfg.worldClock = v),
                new ModuleItem("PingCounter", () -> cfg.pingCounter, v -> cfg.pingCounter = v),
                new ModuleItem("CoordsHud", () -> cfg.coordsHud, v -> cfg.coordsHud = v)
        );
        buildModuleColumn(cfg, c2, topY, colW, colH, "Misc", miscItems);

        // Column 3: Graphics
        int c3 = startX + (colW + colGap) * 2;
        List<ModuleItem> gfxItems = List.of(
                new ModuleItem("Fullbright", () -> cfg.fullBright, v -> cfg.fullBright = v),
                new ModuleItem("CustomCrosshair", () -> cfg.customCrosshair, v -> cfg.customCrosshair = v),
                new ModuleItem("Keystrokes", () -> cfg.keystrokes, v -> cfg.keystrokes = v),
                new ModuleItem("ArmorHud", () -> cfg.armorHud, v -> cfg.armorHud = v),
                new ModuleItem("PotionTimers", () -> cfg.potionTimers, v -> cfg.potionTimers = v),
                new ModuleItem("FpsCounter", () -> cfg.fpsCounter, v -> cfg.fpsCounter = v)
        );
        buildModuleColumn(cfg, c3, topY, colW, colH, "Graphics", gfxItems);

        // Column 4: Display
        int c4 = startX + (colW + colGap) * 3;
        List<ModuleItem> dispItems = List.of(
                new ModuleItem("Watermark", () -> cfg.watermark, v -> cfg.watermark = v),
                new ModuleItem("DirectionHud", () -> cfg.directionHud, v -> cfg.directionHud = v),
                new ModuleItem("BiomeHud", () -> cfg.biomeHud, v -> cfg.biomeHud = v),
                new ModuleItem("CompactPanels", () -> cfg.compactPanels, v -> cfg.compactPanels = v),
                new ModuleItem("ChromaAccent", () -> cfg.chromaAccent, v -> cfg.chromaAccent = v)
        );
        buildModuleColumn(cfg, c4, topY, colW, colH, "Display", dispItems);

        // Column 5: Theme (Fly-style gradient swatches)
        int c5 = startX + (colW + colGap) * 4;
        int themeRowY = topY + 22;
        int maxThemes = Math.min(AetherHudRenderer.THEME_NAMES.length, 13);
        for (int i = 0; i < maxThemes; i++) {
            final int idx = i;
            String tName = AetherHudRenderer.THEME_NAMES[idx];
            boolean selected = cfg.themeIndex == idx && !cfg.chromaAccent;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal((selected ? "§a• §f" : "§f") + tName),
                    b -> {
                        cfg.themeIndex = idx;
                        cfg.chromaAccent = false;
                        AetherConfig.save();
                        statusText = "Тема: " + tName;
                        init();
                    }
            ).dimensions(c5 + 6, themeRowY + i * 15, colW - 12, 14).build());
        }

        // Bottom search bar ("Поиск")
        int searchW = 120;
        searchField = new TextFieldWidget(this.textRenderer, this.width / 2 - searchW / 2, topY + colH + 5, searchW, 15, Text.literal("Поиск"));
        searchField.setPlaceholder(Text.literal("Поиск"));
        addDrawableChild(searchField);

        // Bottom-right Friends & Config panel (Fly style)
        int mgrX = Math.max(8, this.width - 156);
        int mgrY = Math.max(8, this.height - 86);
        addDrawableChild(ButtonWidget.builder(
                Text.literal(showFriendsDrawer ? "Скрыть друзей" : "Друзья (" + cfg.friends.size() + ")"),
                b -> {
                    showFriendsDrawer = !showFriendsDrawer;
                    init();
                }
        ).dimensions(mgrX + 6, mgrY + 18, 136, 15).build());

        if (showFriendsDrawer) {
            int drawerX = mgrX - 168;
            int drawerY = mgrY - 12;
            friendField = new TextFieldWidget(this.textRenderer, drawerX + 6, drawerY + 18, 96, 15, Text.literal("Ник"));
            friendField.setMaxLength(16);
            friendField.setPlaceholder(Text.literal("Ник друга..."));
            addDrawableChild(friendField);

            addDrawableChild(ButtonWidget.builder(Text.literal("§a+"), b -> {
                String nick = friendField.getText().trim();
                if (AetherConfig.addFriend(nick)) {
                    friendField.setText("");
                    statusText = "§aДобавлен друг: §f" + nick;
                    init();
                } else {
                    statusText = "§cНекорректно или уже в списке";
                }
            }).dimensions(drawerX + 106, drawerY + 18, 22, 15).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("§c-"), b -> {
                String nick = friendField.getText().trim();
                if (AetherConfig.removeFriend(nick)) {
                    friendField.setText("");
                    statusText = "§eУдалён друг: §f" + nick;
                    init();
                } else {
                    statusText = "§cНе найден";
                }
            }).dimensions(drawerX + 132, drawerY + 18, 22, 15).build());

            int listStartY = drawerY + 37;
            int shown = 0;
            for (String fName : cfg.friends) {
                if (shown >= 4) break;
                addDrawableChild(ButtonWidget.builder(
                        Text.literal("§a★ §f" + fName + " §c[x]"),
                        b -> {
                            AetherConfig.removeFriend(fName);
                            statusText = "§eУдалён: §f" + fName;
                            init();
                        }
                ).dimensions(drawerX + 6, listStartY + shown * 16, 148, 14).build());
                shown++;
            }

            for (String online : getOnlinePlayers()) {
                if (shown >= 5) break;
                if (!AetherConfig.isFriend(online)) {
                    addDrawableChild(ButtonWidget.builder(
                            Text.literal("§7+ " + online),
                            b -> {
                                AetherConfig.addFriend(online);
                                statusText = "§aДобавлен: §f" + online;
                                init();
                            }
                    ).dimensions(drawerX + 6, listStartY + shown * 16, 148, 14).build());
                    shown++;
                }
            }
        }
    }

    private void buildModuleColumn(AetherConfig cfg, int x, int y, int w, int h, String title, List<ModuleItem> items) {
        String query = searchField != null ? searchField.getText().trim().toLowerCase() : "";
        int rowY = y + 22;
        int idx = 0;
        for (ModuleItem item : items) {
            if (!query.isEmpty() && !item.name().toLowerCase().contains(query)) {
                continue;
            }
            boolean active = item.getter().getAsBoolean();
            String label = (active ? "§a" : "§f") + item.name() + (active ? " §7>" : "");
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(label),
                    b -> {
                        item.setter().accept(!active);
                        AetherConfig.save();
                        init();
                    }
            ).dimensions(x + 5, rowY + idx * 17, w - 10, 15).build());
            idx++;
        }
    }

    private List<String> getOnlinePlayers() {
        List<String> list = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null && mc.player != null) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                String name = entry.getProfile().getName();
                if (name != null && !name.isBlank() && !name.equalsIgnoreCase(mc.player.getName().getString())) {
                    list.add(name);
                }
            }
        }
        return list;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        AetherConfig cfg = AetherConfig.get();
        int accent = AetherHudRenderer.getAccentColor(cfg);
        int secondary = AetherHudRenderer.getSecondaryColor(cfg);

        int colW = 132;
        int colGap = 6;
        int totalW = colW * 5 + colGap * 4;
        int startX = Math.max(8, (this.width - totalW) / 2);
        int topY = Math.max(24, (this.height - 238) / 2);
        int colH = 228;

        String[] headers = {"Combat", "Misc", "Graphics", "Display", "Theme"};
        for (int i = 0; i < headers.length; i++) {
            int cx = startX + i * (colW + colGap);
            context.fill(cx, topY, cx + colW, topY + colH, 0xCC111318);
            context.fill(cx, topY, cx + colW, topY + 1, accent);
            context.drawCenteredTextWithShadow(this.textRenderer, headers[i], cx + colW / 2, topY + 7, 0xFFF8FAFC);
        }

        // Gradient bar previews inside Theme column
        int themeColX = startX + (colW + colGap) * 4;
        int maxThemes = Math.min(AetherHudRenderer.THEME_GRADIENTS.length, 13);
        for (int i = 0; i < maxThemes; i++) {
            int barX = themeColX + 8;
            int barY = topY + 23 + i * 15;
            int barW = 16;
            int barH = 12;
            int cStart = AetherHudRenderer.THEME_GRADIENTS[i][0];
            int cEnd = AetherHudRenderer.THEME_GRADIENTS[i][1];
            context.fillGradient(barX, barY, barX + barW, barY + barH, cStart, cEnd);
        }

        // Bottom-right Friends & Config card
        int mgrX = Math.max(8, this.width - 156);
        int mgrY = Math.max(8, this.height - 86);
        context.fill(mgrX, mgrY, mgrX + 148, mgrY + 78, 0xD8111318);
        context.fill(mgrX, mgrY, mgrX + 148, mgrY + 1, secondary);
        context.drawTextWithShadow(this.textRenderer, "§lFriends & Config", mgrX + 8, mgrY + 6, 0xFFF8FAFC);
        context.drawTextWithShadow(this.textRenderer, statusText.isEmpty() ? "Friends: " + cfg.friends.size() : statusText, mgrX + 8, mgrY + 42, 0xFF94A3B8);

        if (showFriendsDrawer) {
            int drawerX = mgrX - 168;
            int drawerY = mgrY - 12;
            context.fill(drawerX, drawerY, drawerX + 160, drawerY + 124, 0xE6111318);
            context.fill(drawerX, drawerY, drawerX + 160, drawerY + 1, accent);
            context.drawTextWithShadow(this.textRenderer, "§lFriends Manager", drawerX + 8, drawerY + 6, 0xFFF8FAFC);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
