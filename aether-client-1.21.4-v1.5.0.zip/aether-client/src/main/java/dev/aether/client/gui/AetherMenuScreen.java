package dev.aether.client.gui;

import dev.aether.client.AetherClient;
import dev.aether.client.config.AetherConfig;
import dev.aether.client.hud.AetherHudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class AetherMenuScreen extends Screen {
    private enum Tab {
        VISUALS("Visuals"),
        HUD("HUD & Layout"),
        FRIENDS("Friends"),
        THEMES("Themes");

        final String title;
        Tab(String title) { this.title = title; }
    }

    private static final int[] PRESET_COLORS = {
            0xFF38BDF8, // Cyan Sky
            0xFF34D399, // Emerald Mint
            0xFFA78BFA, // Neon Violet
            0xFFFB7185, // Coral Rose
            0xFFFBBF24  // Solar Gold
    };
    private static final String[] PRESET_NAMES = {
            "Cyan Sky", "Emerald Mint", "Neon Violet", "Coral Rose", "Solar Gold"
    };

    private Tab activeTab = Tab.VISUALS;
    private int colorIndex = 0;
    private TextFieldWidget friendInput;
    private String statusMessage = "";

    public AetherMenuScreen() {
        super(Text.literal(AetherClient.CLIENT_NAME));
        AetherConfig cfg = AetherConfig.get();
        for (int i = 0; i < PRESET_COLORS.length; i++) {
            if (PRESET_COLORS[i] == cfg.accentColor) {
                colorIndex = i;
                break;
            }
        }
    }

    @Override
    protected void init() {
        this.clearChildren();
        AetherConfig cfg = AetherConfig.get();

        int panelW = 420;
        int panelH = 248;
        int left = (this.width - panelW) / 2;
        int top = (this.height - panelH) / 2;

        int tabW = panelW / Tab.values().length;
        for (int i = 0; i < Tab.values().length; i++) {
            Tab tab = Tab.values()[i];
            int tx = left + i * tabW;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal((activeTab == tab ? "§l" : "") + tab.title),
                    b -> {
                        activeTab = tab;
                        statusMessage = "";
                        init();
                    }
            ).dimensions(tx + 2, top + 24, tabW - 4, 18).build());
        }

        int contentTop = top + 50;
        int col1 = left + 14;
        int col2 = left + panelW / 2 + 6;
        int btnW = 190;
        int btnH = 20;

        if (activeTab == Tab.VISUALS) {
            addDrawableChild(toggleBtn(col1, contentTop, btnW, btnH, "Master Overlay", cfg.enabled, v -> cfg.enabled = v));
            addDrawableChild(toggleBtn(col2, contentTop, btnW, btnH, "Accent Crosshair", cfg.customCrosshair, v -> cfg.customCrosshair = v));

            addDrawableChild(toggleBtn(col1, contentTop + 26, btnW, btnH, "Nearby Radar", cfg.showRadar, v -> cfg.showRadar = v));
            addDrawableChild(toggleBtn(col2, contentTop + 26, btnW, btnH, "Armor HUD", cfg.showArmorHud, v -> cfg.showArmorHud = v));

            addDrawableChild(toggleBtn(col1, contentTop + 52, btnW, btnH, "Potion Timers", cfg.showPotions, v -> cfg.showPotions = v));
            addDrawableChild(toggleBtn(col2, contentTop + 52, btnW, btnH, "Keystrokes", cfg.showKeystrokes, v -> cfg.showKeystrokes = v));

            addDrawableChild(toggleBtn(col1, contentTop + 78, btnW, btnH, "Fullbright Hint", cfg.fullBright, v -> cfg.fullBright = v));
            addDrawableChild(toggleBtn(col2, contentTop + 78, btnW, btnH, "Chroma RGB", cfg.chromaAccent, v -> cfg.chromaAccent = v));
        } else if (activeTab == Tab.HUD) {
            addDrawableChild(toggleBtn(col1, contentTop, btnW, btnH, "Watermark", cfg.showWatermark, v -> cfg.showWatermark = v));
            addDrawableChild(toggleBtn(col2, contentTop, btnW, btnH, "FPS Counter", cfg.showFps, v -> cfg.showFps = v));

            addDrawableChild(toggleBtn(col1, contentTop + 26, btnW, btnH, "Coordinates", cfg.showCoords, v -> cfg.showCoords = v));
            addDrawableChild(toggleBtn(col2, contentTop + 26, btnW, btnH, "Facing Direction", cfg.showDirection, v -> cfg.showDirection = v));

            addDrawableChild(toggleBtn(col1, contentTop + 52, btnW, btnH, "Biome Name", cfg.showBiome, v -> cfg.showBiome = v));
            addDrawableChild(toggleBtn(col2, contentTop + 52, btnW, btnH, "Ping & World Clock", cfg.showPing && cfg.showTime, v -> {
                cfg.showPing = v;
                cfg.showTime = v;
            }));

            addDrawableChild(ButtonWidget.builder(Text.literal("Reset HUD & Keystrokes Pos"), b -> {
                cfg.hudX = 10;
                cfg.hudY = 10;
                cfg.keystrokesX = 10;
                cfg.keystrokesY = 126;
                AetherConfig.save();
                statusMessage = "§aPositions reset to default";
            }).dimensions(col1, contentTop + 82, panelW - 28, btnH).build());
        } else if (activeTab == Tab.FRIENDS) {
            friendInput = new TextFieldWidget(this.textRenderer, col1, contentTop, 250, 20, Text.literal("Player nickname"));
            friendInput.setMaxLength(16);
            friendInput.setPlaceholder(Text.literal("Enter player nickname..."));
            addDrawableChild(friendInput);

            addDrawableChild(ButtonWidget.builder(Text.literal("§a+ Add"), b -> {
                String nick = friendInput.getText().trim();
                if (AetherConfig.addFriend(nick)) {
                    friendInput.setText("");
                    statusMessage = "§aAdded friend: §f" + nick;
                    init();
                } else {
                    statusMessage = "§cInvalid or duplicate name";
                }
            }).dimensions(col1 + 256, contentTop, 62, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("§c- Del"), b -> {
                String nick = friendInput.getText().trim();
                if (AetherConfig.removeFriend(nick)) {
                    friendInput.setText("");
                    statusMessage = "§eRemoved friend: §f" + nick;
                    init();
                } else {
                    statusMessage = "§cFriend not found";
                }
            }).dimensions(col1 + 324, contentTop, 68, 20).build());

            List<String> onlineNames = getOnlinePlayers();
            int quickY = contentTop + 26;
            int shown = 0;
            for (String online : onlineNames) {
                if (shown >= 4) break;
                boolean already = AetherConfig.isFriend(online);
                addDrawableChild(ButtonWidget.builder(
                        Text.literal((already ? "§a★ " : "§7+ ") + online),
                        b -> {
                            if (AetherConfig.isFriend(online)) {
                                AetherConfig.removeFriend(online);
                                statusMessage = "§eRemoved: §f" + online;
                            } else {
                                AetherConfig.addFriend(online);
                                statusMessage = "§aAdded: §f" + online;
                            }
                            init();
                        }
                ).dimensions(col1 + shown * 98, quickY, 94, 16).build());
                shown++;
            }

            int listY = contentTop + 50;
            int maxRows = 4;
            int count = Math.min(cfg.friends.size(), maxRows * 2);
            for (int i = 0; i < count; i++) {
                String friendName = cfg.friends.get(i);
                int rx = (i % 2 == 0) ? col1 : col2;
                int ry = listY + (i / 2) * 22;
                addDrawableChild(ButtonWidget.builder(
                        Text.literal("§a★ §f" + friendName + " §c[x]"),
                        b -> {
                            AetherConfig.removeFriend(friendName);
                            statusMessage = "§eRemoved: §f" + friendName;
                            init();
                        }
                ).dimensions(rx, ry, btnW, 18).build());
            }
        } else if (activeTab == Tab.THEMES) {
            addDrawableChild(ButtonWidget.builder(Text.literal("Accent Preset: " + PRESET_NAMES[colorIndex]), b -> {
                colorIndex = (colorIndex + 1) % PRESET_COLORS.length;
                cfg.accentColor = PRESET_COLORS[colorIndex];
                cfg.chromaAccent = false;
                b.setMessage(Text.literal("Accent Preset: " + PRESET_NAMES[colorIndex]));
                AetherConfig.save();
            }).dimensions(col1, contentTop, btnW, btnH).build());

            addDrawableChild(toggleBtn(col2, contentTop, btnW, btnH, "Chroma RGB", cfg.chromaAccent, v -> cfg.chromaAccent = v));

            addDrawableChild(ButtonWidget.builder(Text.literal("Panel Opacity: " + (cfg.panelOpacity * 100 / 255) + "%"), b -> {
                int[] steps = {110, 155, 195, 230};
                int next = steps[0];
                for (int i = 0; i < steps.length; i++) {
                    if (Math.abs(cfg.panelOpacity - steps[i]) < 15) {
                        next = steps[(i + 1) % steps.length];
                        break;
                    }
                }
                cfg.panelOpacity = next;
                b.setMessage(Text.literal("Panel Opacity: " + (cfg.panelOpacity * 100 / 255) + "%"));
                AetherConfig.save();
            }).dimensions(col1, contentTop + 28, panelW - 28, btnH).build());
        }
    }

    private ButtonWidget toggleBtn(int x, int y, int w, int h, String label, boolean current, java.util.function.Consumer<Boolean> setter) {
        return ButtonWidget.builder(
                Text.literal(label + ": " + (current ? "§aON" : "§cOFF")),
                b -> {
                    boolean next = !current;
                    setter.accept(next);
                    AetherConfig.save();
                    init();
                }
        ).dimensions(x, y, w, h).build();
    }

    private List<String> getOnlinePlayers() {
        List<String> list = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null && mc.player != null) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                String name = entry.getProfile().getName();
                if (name != null && !name.isBlank() && !name.equalsIgnoreCase(mc.player.getName().getString())) {
                    list.add(name);
                }
            }
        }
        return list;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        AetherConfig cfg = AetherConfig.get();
        if (activeTab == Tab.HUD && button == 0 && mouseX < 190 && mouseY < 115) {
            cfg.hudX = (int) mouseX;
            cfg.hudY = (int) mouseY;
            AetherConfig.save();
            statusMessage = "§aMain HUD moved to " + cfg.hudX + ", " + cfg.hudY;
        } else if (activeTab == Tab.HUD && button == 1 && mouseX < 190 && mouseY >= 115) {
            cfg.keystrokesX = (int) mouseX;
            cfg.keystrokesY = (int) mouseY;
            AetherConfig.save();
            statusMessage = "§aKeystrokes moved to " + cfg.keystrokesX + ", " + cfg.keystrokesY;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int panelW = 420;
        int panelH = 248;
        int left = (this.width - panelW) / 2;
        int top = (this.height - panelH) / 2;
        int accent = AetherHudRenderer.getAccentColor(AetherConfig.get());

        context.fill(left, top, left + panelW, top + panelH, 0xE6090D16);
        context.fill(left, top, left + panelW, top + 2, accent);
        context.fill(left, top + 21, left + panelW, top + 22, (accent & 0x00FFFFFF) | 0x33000000);

        context.drawTextWithShadow(
                this.textRenderer,
                "§l" + AetherClient.CLIENT_NAME + " §r§7v" + AetherClient.VERSION + " §8| §f" + activeTab.title,
                left + 12,
                top + 7,
                accent
        );

        String hint = activeTab == Tab.HUD
                ? "LMB/RMB on left screen to place HUD/Keystrokes"
                : (statusMessage.isEmpty() ? "Friends: " + AetherConfig.get().friends.size() : statusMessage);
        context.drawTextWithShadow(this.textRenderer, hint, left + 12, top + panelH - 14, 0xFF94A3B8);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
