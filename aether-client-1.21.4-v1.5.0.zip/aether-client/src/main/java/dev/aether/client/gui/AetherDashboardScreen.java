package dev.aether.client.gui;

import dev.aether.client.AetherClient;
import dev.aether.client.config.AetherConfig;
import dev.aether.client.hud.AetherHudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class AetherDashboardScreen extends Screen {

    private enum NavSection {
        ALL("Все функции"),
        PVP("PvP"),
        VISUALS("Визуальные"),
        MISC("Прочее"),
        FRIENDS("Друзья"),
        THEMES("Темы");

        final String label;
        NavSection(String label) { this.label = label; }
    }

    private record FeatureCard(String name, String category, String description, BooleanSupplier getter, Consumer<Boolean> setter) {}

    private NavSection activeSection = NavSection.ALL;
    private TextFieldWidget searchBox;
    private TextFieldWidget friendInput;
    private String statusMessage = "";

    public AetherDashboardScreen() {
        super(Text.literal(AetherClient.CLIENT_NAME));
    }

    @Override
    protected void init() {
        this.clearChildren();
        AetherConfig cfg = AetherConfig.get();

        int sidebarW = 112;
        int margin = 10;
        int topBarH = 26;
        int mainX = margin + sidebarW + 8;
        int mainY = margin + topBarH + 6;
        int mainW = Math.max(240, this.width - mainX - margin);
        int mainH = Math.max(180, this.height - mainY - margin);

        // Left sidebar navigation
        int navY = margin + 44;
        for (NavSection sec : NavSection.values()) {
            boolean selected = (activeSection == sec);
            addDrawableChild(ButtonWidget.builder(
                    Text.literal((selected ? "§l" : "") + sec.label),
                    b -> {
                        activeSection = sec;
                        statusMessage = "";
                        init();
                    }
            ).dimensions(margin + 6, navY, sidebarW - 12, 17).build());
            navY += 20;
        }

        // Top search bar
        int searchW = Math.min(200, Math.max(110, mainW - 160));
        searchBox = new TextFieldWidget(this.textRenderer, mainX + 95, margin + 5, searchW, 16, Text.literal("Поиск"));
        searchBox.setPlaceholder(Text.literal("Поиск функций..."));
        addDrawableChild(searchBox);

        if (activeSection == NavSection.FRIENDS) {
            buildFriendsView(cfg, mainX + 10, mainY + 12, mainW - 20);
            return;
        }

        if (activeSection == NavSection.THEMES) {
            buildThemesView(cfg, mainX + 10, mainY + 12, mainW - 20);
            return;
        }

        List<FeatureCard> allCards = List.of(
                new FeatureCard("ArmorDurability", "PvP", "Показывает прочность брони под слотами", () -> cfg.armorDurability, v -> cfg.armorDurability = v),
                new FeatureCard("HitParticles", "PvP", "Акцентные частицы при попадании по цели", () -> cfg.hitParticles, v -> cfg.hitParticles = v),
                new FeatureCard("TargetInfo", "PvP", "Компактная визуальная карточка цели", () -> cfg.targetInfo, v -> cfg.targetInfo = v),
                new FeatureCard("SwingVisual", "PvP", "Плавная визуальная анимация взмаха руки", () -> cfg.swingVisual, v -> cfg.swingVisual = v),
                new FeatureCard("HitFlash", "PvP", "Мягкая подсветка при ударе по сущности", () -> cfg.hitFlash, v -> cfg.hitFlash = v),

                new FeatureCard("CustomCrosshair", "Визуальные", "Кастомный перекрестный прицел в цвете темы", () -> cfg.customCrosshair, v -> cfg.customCrosshair = v),
                new FeatureCard("Keystrokes", "Визуальные", "Отображение нажатий WASD, мыши и пробела", () -> cfg.keystrokes, v -> cfg.keystrokes = v),
                new FeatureCard("ArmorHud", "Визуальные", "Панель надетой брони рядом с хотбаром", () -> cfg.armorHud, v -> cfg.armorHud = v),
                new FeatureCard("PotionTimers", "Визуальные", "Таймеры активных зелий в правом углу", () -> cfg.potionTimers, v -> cfg.potionTimers = v),
                new FeatureCard("FpsCounter", "Визуальные", "Счётчик кадров в секунду на основном HUD", () -> cfg.fpsCounter, v -> cfg.fpsCounter = v),
                new FeatureCard("Watermark", "Визуальные", "Фирменный бейдж Aether Visuals и версия", () -> cfg.watermark, v -> cfg.watermark = v),

                new FeatureCard("FriendsHighlight", "Прочее", "Помечает друзей звёздочкой на радаре", () -> cfg.friendsHighlight, v -> cfg.friendsHighlight = v),
                new FeatureCard("NearbyRadar", "Прочее", "Список игроков в радиусе 64 блоков", () -> cfg.nearbyRadar, v -> cfg.nearbyRadar = v),
                new FeatureCard("CoordsHud", "Прочее", "Текущие координаты X, Y, Z игрока", () -> cfg.coordsHud, v -> cfg.coordsHud = v),
                new FeatureCard("DirectionHud", "Прочее", "Направление взгляда (North / South / East / West)", () -> cfg.directionHud, v -> cfg.directionHud = v),
                new FeatureCard("BiomeHud", "Прочее", "Название текущего биома под ногами", () -> cfg.biomeHud, v -> cfg.biomeHud = v),
                new FeatureCard("WorldClock", "Прочее", "Игровое время в формате 24-часовых часов", () -> cfg.worldClock, v -> cfg.worldClock = v),
                new FeatureCard("PingCounter", "Прочее", "Задержка соединения в миллисекундах", () -> cfg.pingCounter, v -> cfg.pingCounter = v),
                new FeatureCard("ChromaAccent", "Прочее", "Плавный перелив акцентного цвета RGB", () -> cfg.chromaAccent, v -> cfg.chromaAccent = v)
        );

        String query = searchBox != null ? searchBox.getText().trim().toLowerCase() : "";
        List<FeatureCard> filtered = new ArrayList<>();
        for (FeatureCard c : allCards) {
            boolean catMatch = switch (activeSection) {
                case ALL -> true;
                case PVP -> "PvP".equals(c.category());
                case VISUALS -> "Визуальные".equals(c.category());
                case MISC -> "Прочее".equals(c.category());
                default -> false;
            };
            boolean textMatch = query.isEmpty()
                    || c.name().toLowerCase().contains(query)
                    || c.description().toLowerCase().contains(query);
            if (catMatch && textMatch) {
                filtered.add(c);
            }
        }

        int cols = mainW >= 540 ? 3 : 2;
        int cardGap = 8;
        int cardW = (mainW - 20 - cardGap * (cols - 1)) / cols;
        int cardH = 44;
        int startX = mainX + 10;
        int startY = mainY + 10;

        int maxRows = Math.max(1, (mainH - 18) / (cardH + cardGap));
        int maxCards = maxRows * cols;

        for (int i = 0; i < Math.min(filtered.size(), maxCards); i++) {
            FeatureCard card = filtered.get(i);
            int r = i / cols;
            int c = i % cols;
            int cx = startX + c * (cardW + cardGap);
            int cy = startY + r * (cardH + cardGap);

            boolean isOn = card.getter().getAsBoolean();
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(isOn ? "§aВКЛ" : "§7ВЫКЛ"),
                    b -> {
                        card.setter().accept(!isOn);
                        AetherConfig.save();
                        statusMessage = card.name() + ": " + (!isOn ? "§aвключено" : "§7выключено");
                        init();
                    }
            ).dimensions(cx + cardW - 44, cy + 5, 38, 14).build());
        }
    }

    private void buildFriendsView(AetherConfig cfg, int x, int y, int w) {
        friendInput = new TextFieldWidget(this.textRenderer, x, y, Math.min(220, w - 110), 18, Text.literal("Ник друга"));
        friendInput.setMaxLength(16);
        friendInput.setPlaceholder(Text.literal("Введите ник игрока..."));
        addDrawableChild(friendInput);

        int inputEnd = x + Math.min(220, w - 110) + 6;
        addDrawableChild(ButtonWidget.builder(Text.literal("§a+ Добавить"), b -> {
            String nick = friendInput.getText().trim();
            if (AetherConfig.addFriend(nick)) {
                friendInput.setText("");
                statusMessage = "§aДобавлен в друзья: §f" + nick;
                init();
            } else {
                statusMessage = "§cНекорректный ник или уже добавлен";
            }
        }).dimensions(inputEnd, y, 64, 18).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("§c- Удалить"), b -> {
            String nick = friendInput.getText().trim();
            if (AetherConfig.removeFriend(nick)) {
                friendInput.setText("");
                statusMessage = "§eУдалён из друзей: §f" + nick;
                init();
            } else {
                statusMessage = "§cИгрок не найден в списке";
            }
        }).dimensions(inputEnd + 68, y, 64, 18).build());

        int quickY = y + 24;
        int shownOnline = 0;
        for (String online : getOnlinePlayers()) {
            if (shownOnline >= 4) break;
            boolean already = AetherConfig.isFriend(online);
            addDrawableChild(ButtonWidget.builder(
                    Text.literal((already ? "§a★ " : "§7+ ") + online),
                    b -> {
                        if (already) {
                            AetherConfig.removeFriend(online);
                            statusMessage = "§eУдалён: §f" + online;
                        } else {
                            AetherConfig.addFriend(online);
                            statusMessage = "§aДобавлен: §f" + online;
                        }
                        init();
                    }
            ).dimensions(x + shownOnline * 108, quickY, 102, 15).build());
            shownOnline++;
        }

        int listY = y + 48;
        int halfW = (w - 8) / 2;
        for (int i = 0; i < Math.min(cfg.friends.size(), 8); i++) {
            String fName = cfg.friends.get(i);
            int fx = x + (i % 2) * (halfW + 8);
            int fy = listY + (i / 2) * 20;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal("§a★ §f" + fName + "  §c[Убрать]"),
                    b -> {
                        AetherConfig.removeFriend(fName);
                        statusMessage = "§eУдалён: §f" + fName;
                        init();
                    }
            ).dimensions(fx, fy, halfW, 16).build());
        }
    }

    private void buildThemesView(AetherConfig cfg, int x, int y, int w) {
        int halfW = (w - 8) / 2;
        for (int i = 0; i < AetherHudRenderer.THEME_NAMES.length; i++) {
            final int idx = i;
            String tName = AetherHudRenderer.THEME_NAMES[idx];
            boolean active = (cfg.themeIndex == idx && !cfg.chromaAccent);
            int tx = x + (i % 2) * (halfW + 8);
            int ty = y + (i / 2) * 24;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal((active ? "§a● §f" : "§7○ §f") + tName),
                    b -> {
                        cfg.themeIndex = idx;
                        cfg.chromaAccent = false;
                        AetherConfig.save();
                        statusMessage = "§aТема применена: §f" + tName;
                        init();
                    }
            ).dimensions(tx, ty, halfW, 18).build());
        }

        int extraY = y + 80;
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Прозрачность HUD: " + (cfg.panelOpacity * 100 / 255) + "%"),
                b -> {
                    int[] levels = {120, 165, 195, 230};
                    int next = levels[0];
                    for (int i = 0; i < levels.length; i++) {
                        if (Math.abs(cfg.panelOpacity - levels[i]) < 15) {
                            next = levels[(i + 1) % levels.length];
                            break;
                        }
                    }
                    cfg.panelOpacity = next;
                    AetherConfig.save();
                    init();
                }
        ).dimensions(x, extraY, halfW, 18).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Сброс позиций HUD"),
                b -> {
                    cfg.hudX = 10;
                    cfg.hudY = 10;
                    cfg.keystrokesX = 10;
                    cfg.keystrokesY = 148;
                    AetherConfig.save();
                    statusMessage = "§aПозиции HUD сброшены";
                }
        ).dimensions(x + halfW + 8, extraY, halfW, 18).build());
    }

    private List<String> getOnlinePlayers() {
        List<String> list = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null && mc.player != null) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                String name = entry.getProfile().getName();
                if (name != null && !name.isBlank() && !name.equalsIgnoreCase(mc.player.getName().getString())) {
                    list.add(name);
                }
            }
        }
        return list;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        AetherConfig cfg = AetherConfig.get();
        int accent = AetherHudRenderer.getAccentColor(cfg);
        int secondary = AetherHudRenderer.getSecondaryColor(cfg);

        int sidebarW = 112;
        int margin = 10;
        int topBarH = 26;
        int mainX = margin + sidebarW + 8;
        int mainY = margin + topBarH + 6;
        int mainW = Math.max(240, this.width - mainX - margin);
        int mainH = Math.max(180, this.height - mainY - margin);

        // Left sidebar container
        context.fill(margin, margin, margin + sidebarW, this.height - margin, 0xE60B0F18);
        context.fill(margin, margin, margin + sidebarW, margin + 2, accent);
        context.drawTextWithShadow(this.textRenderer, "§lAETHER", margin + 10, margin + 10, accent);
        context.drawTextWithShadow(this.textRenderer, "§7v" + AetherClient.VERSION, margin + 10, margin + 21, 0xFF94A3B8);

        // Top bar container
        context.fill(mainX, margin, this.width - margin, margin + topBarH, 0xE60B0F18);
        context.fill(mainX, margin, this.width - margin, margin + 2, secondary);
        context.drawTextWithShadow(this.textRenderer, "§l" + activeSection.label, mainX + 10, margin + 9, 0xFFF8FAFC);

        // Main panel container
        context.fill(mainX, mainY, mainX + mainW, mainY + mainH, 0xDC0B0F18);
        context.fill(mainX, mainY, mainX + mainW, mainY + 1, (accent & 0x00FFFFFF) | 0x66000000);

        if (activeSection != NavSection.FRIENDS && activeSection != NavSection.THEMES) {
            renderCardBackgrounds(context, cfg, accent, mainX, mainY, mainW, mainH);
        }

        if (!statusMessage.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, statusMessage, mainX + 10, mainY + mainH - 12, 0xFF94A3B8);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderCardBackgrounds(DrawContext context, AetherConfig cfg, int accent,
                                      int mainX, int mainY, int mainW, int mainH) {
        List<FeatureCard> allCards = List.of(
                new FeatureCard("ArmorDurability", "PvP", "Показывает прочность брони под слотами", () -> cfg.armorDurability, v -> cfg.armorDurability = v),
                new FeatureCard("HitParticles", "PvP", "Акцентные частицы при попадании по цели", () -> cfg.hitParticles, v -> cfg.hitParticles = v),
                new FeatureCard("TargetInfo", "PvP", "Компактная визуальная карточка цели", () -> cfg.targetInfo, v -> cfg.targetInfo = v),
                new FeatureCard("SwingVisual", "PvP", "Плавная визуальная анимация взмаха руки", () -> cfg.swingVisual, v -> cfg.swingVisual = v),
                new FeatureCard("HitFlash", "PvP", "Мягкая подсветка при ударе по сущности", () -> cfg.hitFlash, v -> cfg.hitFlash = v),

                new FeatureCard("CustomCrosshair", "Визуальные", "Кастомный перекрестный прицел в цвете темы", () -> cfg.customCrosshair, v -> cfg.customCrosshair = v),
                new FeatureCard("Keystrokes", "Визуальные", "Отображение нажатий WASD, мыши и пробела", () -> cfg.keystrokes, v -> cfg.keystrokes = v),
                new FeatureCard("ArmorHud", "Визуальные", "Панель надетой брони рядом с хотбаром", () -> cfg.armorHud, v -> cfg.armorHud = v),
                new FeatureCard("PotionTimers", "Визуальные", "Таймеры активных зелий в правом углу", () -> cfg.potionTimers, v -> cfg.potionTimers = v),
                new FeatureCard("FpsCounter", "Визуальные", "Счётчик кадров в секунду на основном HUD", () -> cfg.fpsCounter, v -> cfg.fpsCounter = v),
                new FeatureCard("Watermark", "Визуальные", "Фирменный бейдж Aether Visuals и версия", () -> cfg.watermark, v -> cfg.watermark = v),

                new FeatureCard("FriendsHighlight", "Прочее", "Помечает друзей звёздочкой на радаре", () -> cfg.friendsHighlight, v -> cfg.friendsHighlight = v),
                new FeatureCard("NearbyRadar", "Прочее", "Список игроков в радиусе 64 блоков", () -> cfg.nearbyRadar, v -> cfg.nearbyRadar = v),
                new FeatureCard("CoordsHud", "Прочее", "Текущие координаты X, Y, Z игрока", () -> cfg.coordsHud, v -> cfg.coordsHud = v),
                new FeatureCard("DirectionHud", "Прочее", "Направление взгляда (North / South / East / West)", () -> cfg.directionHud, v -> cfg.directionHud = v),
                new FeatureCard("BiomeHud", "Прочее", "Название текущего биома под ногами", () -> cfg.biomeHud, v -> cfg.biomeHud = v),
                new FeatureCard("WorldClock", "Прочее", "Игровое время в формате 24-часовых часов", () -> cfg.worldClock, v -> cfg.worldClock = v),
                new FeatureCard("PingCounter", "Прочее", "Задержка соединения в миллисекундах", () -> cfg.pingCounter, v -> cfg.pingCounter = v),
                new FeatureCard("ChromaAccent", "Прочее", "Плавный перелив акцентного цвета RGB", () -> cfg.chromaAccent, v -> cfg.chromaAccent = v)
        );

        String query = searchBox != null ? searchBox.getText().trim().toLowerCase() : "";
        List<FeatureCard> filtered = new ArrayList<>();
        for (FeatureCard c : allCards) {
            boolean catMatch = switch (activeSection) {
                case ALL -> true;
                case PVP -> "PvP".equals(c.category());
                case VISUALS -> "Визуальные".equals(c.category());
                case MISC -> "Прочее".equals(c.category());
                default -> false;
            };
            boolean textMatch = query.isEmpty()
                    || c.name().toLowerCase().contains(query)
                    || c.description().toLowerCase().contains(query);
            if (catMatch && textMatch) {
                filtered.add(c);
            }
        }

        int cols = mainW >= 540 ? 3 : 2;
        int cardGap = 8;
        int cardW = (mainW - 20 - cardGap * (cols - 1)) / cols;
        int cardH = 44;
        int startX = mainX + 10;
        int startY = mainY + 10;

        int maxRows = Math.max(1, (mainH - 18) / (cardH + cardGap));
        int maxCards = maxRows * cols;

        for (int i = 0; i < Math.min(filtered.size(), maxCards); i++) {
            FeatureCard card = filtered.get(i);
            int r = i / cols;
            int c = i % cols;
            int cx = startX + c * (cardW + cardGap);
            int cy = startY + r * (cardH + cardGap);

            boolean isOn = card.getter().getAsBoolean();
            context.fill(cx, cy, cx + cardW, cy + cardH, 0xCC121826);
            context.fill(cx, cy, cx + 2, cy + cardH, isOn ? accent : 0xFF334155);

            context.drawTextWithShadow(this.textRenderer, "§l" + card.name(), cx + 8, cy + 6, isOn ? 0xFFF8FAFC : 0xFFCBD5E1);
            context.drawTextWithShadow(this.textRenderer, "§8" + card.category(), cx + 8, cy + 17, accent);

            String desc = this.textRenderer.trimToWidth(card.description(), cardW - 16);
            context.drawTextWithShadow(this.textRenderer, desc, cx + 8, cy + 29, 0xFF94A3B8);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
