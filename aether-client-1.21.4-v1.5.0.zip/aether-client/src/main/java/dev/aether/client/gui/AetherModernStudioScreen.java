package dev.aether.client.gui;

import dev.aether.client.AetherClient;
import dev.aether.client.config.AetherConfig;
import dev.aether.client.hud.AetherHudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class AetherModernStudioScreen extends Screen {

    private enum FilterTab {
        ALL("Все"),
        PVP("PvP"),
        VISUALS("Визуал"),
        MISC("HUD и мир");

        final String label;
        FilterTab(String label) { this.label = label; }
    }

    private record ModuleEntry(String name, String category, String hint, BooleanSupplier getter, Consumer<Boolean> setter) {}

    private FilterTab activeFilter = FilterTab.ALL;
    private TextFieldWidget searchInput;
    private TextFieldWidget friendInput;
    private String statusLine = "";

    public AetherModernStudioScreen() {
        super(Text.literal(AetherClient.CLIENT_NAME));
    }

    @Override
    protected void init() {
        this.clearChildren();
        AetherConfig cfg = AetherConfig.get();

        int pad = 12;
        int topH = 30;
        int rightDockW = Math.min(200, Math.max(155, this.width / 4));
        int leftW = Math.max(240, this.width - pad * 3 - rightDockW);
        int bodyY = pad + topH + 8;
        int bodyH = Math.max(180, this.height - bodyY - pad);

        // Top bar category pills
        int pillX = pad + 128;
        for (FilterTab tab : FilterTab.values()) {
            int pw = this.textRenderer.getWidth(tab.label) + 14;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal((activeFilter == tab ? "§l[" + tab.label + "]" : tab.label)),
                    b -> {
                        activeFilter = tab;
                        init();
                    }
            ).dimensions(pillX, pad + 7, pw, 16).build());
            pillX += pw + 5;
        }

        // Top-right search input
        int searchW = Math.min(180, Math.max(100, this.width - pillX - pad - 10));
        searchInput = new TextFieldWidget(this.textRenderer, this.width - pad - searchW - 6, pad + 7, searchW, 16, Text.literal("Поиск"));
        searchInput.setPlaceholder(Text.literal("Поиск модулей..."));
        addDrawableChild(searchInput);

        // Left area: 2-column modern cards
        List<ModuleEntry> modules = List.of(
                new ModuleEntry("ArmorDurability", "PvP", "Прочность брони под иконками", () -> cfg.armorDurability, v -> cfg.armorDurability = v),
                new ModuleEntry("HitParticles", "PvP", "Акцентные частицы при ударах", () -> cfg.hitParticles, v -> cfg.hitParticles = v),
                new ModuleEntry("TargetInfo", "PvP", "Визуальный блок информации о цели", () -> cfg.targetInfo, v -> cfg.targetInfo = v),
                new ModuleEntry("SwingVisual", "PvP", "Плавная анимация взмаха", () -> cfg.swingVisual, v -> cfg.swingVisual = v),
                new ModuleEntry("HitFlash", "PvP", "Подсветка попаданий", () -> cfg.hitFlash, v -> cfg.hitFlash = v),

                new ModuleEntry("CustomCrosshair", "Визуал", "Перекрестие по центру экрана", () -> cfg.customCrosshair, v -> cfg.customCrosshair = v),
                new ModuleEntry("Keystrokes", "Визуал", "Клавиши WASD, мышь и Space", () -> cfg.keystrokes, v -> cfg.keystrokes = v),
                new ModuleEntry("ArmorHud", "Визуал", "Индикатор брони у хотбара", () -> cfg.armorHud, v -> cfg.armorHud = v),
                new ModuleEntry("PotionTimers", "Визуал", "Таймеры эффектов зелий", () -> cfg.potionTimers, v -> cfg.potionTimers = v),
                new ModuleEntry("FpsCounter", "Визуал", "Счётчик FPS в углу экрана", () -> cfg.fpsCounter, v -> cfg.fpsCounter = v),
                new ModuleEntry("Watermark", "Визуал", "Бейдж Aether Visuals", () -> cfg.watermark, v -> cfg.watermark = v),

                new ModuleEntry("FriendsHighlight", "HUD и мир", "Выделяет друзей на радаре", () -> cfg.friendsHighlight, v -> cfg.friendsHighlight = v),
                new ModuleEntry("NearbyRadar", "HUD и мир", "Радар игроков рядом (64м)", () -> cfg.nearbyRadar, v -> cfg.nearbyRadar = v),
                new ModuleEntry("CoordsHud", "HUD и мир", "Координаты XYZ", () -> cfg.coordsHud, v -> cfg.coordsHud = v),
                new ModuleEntry("DirectionHud", "HUD и мир", "Направление взгляда", () -> cfg.directionHud, v -> cfg.directionHud = v),
                new ModuleEntry("BiomeHud", "HUD и мир", "Текущий биом", () -> cfg.biomeHud, v -> cfg.biomeHud = v),
                new ModuleEntry("WorldClock", "HUD и мир", "Игровые часы 24ч", () -> cfg.worldClock, v -> cfg.worldClock = v),
                new ModuleEntry("PingCounter", "HUD и мир", "Пинг до сервера", () -> cfg.pingCounter, v -> cfg.pingCounter = v),
                new ModuleEntry("ChromaAccent", "HUD и мир", "RGB перелив акцента", () -> cfg.chromaAccent, v -> cfg.chromaAccent = v)
        );

        String q = searchInput != null ? searchInput.getText().trim().toLowerCase() : "";
        List<ModuleEntry> filtered = new ArrayList<>();
        for (ModuleEntry m : modules) {
            boolean tabOk = switch (activeFilter) {
                case ALL -> true;
                case PVP -> "PvP".equals(m.category());
                case VISUALS -> "Визуал".equals(m.category());
                case MISC -> "HUD и мир".equals(m.category());
            };
            boolean qOk = q.isEmpty() || m.name().toLowerCase().contains(q) || m.hint().toLowerCase().contains(q);
            if (tabOk && qOk) filtered.add(m);
        }

        int gridCols = 2;
        int gap = 8;
        int cardW = (leftW - 20 - gap) / gridCols;
        int cardH = 38;
        int gridX = pad + 10;
        int gridY = bodyY + 10;
        int maxRows = Math.max(1, (bodyH - 18) / (cardH + gap));
        int maxItems = maxRows * gridCols;

        for (int i = 0; i < Math.min(filtered.size(), maxItems); i++) {
            ModuleEntry entry = filtered.get(i);
            int r = i / gridCols;
            int c = i % gridCols;
            int cx = gridX + c * (cardW + gap);
            int cy = gridY + r * (cardH + gap);

            boolean active = entry.getter().getAsBoolean();
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(active ? "§a●" : "§7○"),
                    b -> {
                        entry.setter().accept(!active);
                        AetherConfig.save();
                        statusLine = entry.name() + ": " + (!active ? "§aON" : "§7OFF");
                        init();
                    }
            ).dimensions(cx + cardW - 26, cy + 5, 20, 14).build());
        }

        // Right dock: Friends Manager + Themes + HUD controls
        int dockX = pad * 2 + leftW;
        int dockY = bodyY;
        int innerW = rightDockW - 16;

        // Friends input + Add / Del
        int fY = dockY + 24;
        friendInput = new TextFieldWidget(this.textRenderer, dockX + 8, fY, innerW - 44, 15, Text.literal("Ник"));
        friendInput.setMaxLength(16);
        friendInput.setPlaceholder(Text.literal("Ник друга..."));
        addDrawableChild(friendInput);

        addDrawableChild(ButtonWidget.builder(Text.literal("§a+"), b -> {
            String nick = friendInput.getText().trim();
            if (AetherConfig.addFriend(nick)) {
                friendInput.setText("");
                statusLine = "§a+ " + nick;
                init();
            } else {
                statusLine = "§cОшибка ника";
            }
        }).dimensions(dockX + 8 + innerW - 40, fY, 18, 15).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("§c-"), b -> {
            String nick = friendInput.getText().trim();
            if (AetherConfig.removeFriend(nick)) {
                friendInput.setText("");
                statusLine = "§e- " + nick;
                init();
            } else {
                statusLine = "§cНе найден";
            }
        }).dimensions(dockX + 8 + innerW - 20, fY, 18, 15).build());

        int listY = fY + 19;
        int shown = 0;
        for (String fName : cfg.friends) {
            if (shown >= 3) break;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal("§a★ §f" + fName + " §c×"),
                    b -> {
                        AetherConfig.removeFriend(fName);
                        statusLine = "§eУдалён " + fName;
                        init();
                    }
            ).dimensions(dockX + 8, listY + shown * 15, innerW, 13).build());
            shown++;
        }

        for (String online : getOnlinePlayers()) {
            if (shown >= 4) break;
            if (!AetherConfig.isFriend(online)) {
                addDrawableChild(ButtonWidget.builder(
                        Text.literal("§7+ " + online),
                        b -> {
                            AetherConfig.addFriend(online);
                            statusLine = "§a+ " + online;
                            init();
                        }
                ).dimensions(dockX + 8, listY + shown * 15, innerW, 13).build());
                shown++;
            }
        }

        // Theme cycle & HUD actions at bottom of right dock
        int themeY = dockY + bodyH - 44;
        String currentTheme = AetherHudRenderer.THEME_NAMES[Math.floorMod(cfg.themeIndex, AetherHudRenderer.THEME_NAMES.length)];
        addDrawableChild(ButtonWidget.builder(
                Text.literal("Тема: " + currentTheme),
                b -> {
                    cfg.themeIndex = (cfg.themeIndex + 1) % AetherHudRenderer.THEME_NAMES.length;
                    cfg.chromaAccent = false;
                    AetherConfig.save();
                    statusLine = "Тема: " + AetherHudRenderer.THEME_NAMES[cfg.themeIndex];
                    init();
                }
        ).dimensions(dockX + 8, themeY, innerW, 16).build());

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Сброс позиций HUD"),
                b -> {
                    cfg.hudX = 10;
                    cfg.hudY = 10;
                    cfg.keystrokesX = 10;
                    cfg.keystrokesY = 148;
                    AetherConfig.save();
                    statusLine = "§aПозиции сброшены";
                }
        ).dimensions(dockX + 8, themeY + 20, innerW, 16).build());
    }

    private List<String> getOnlinePlayers() {
        List<String> list = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null && mc.player != null) {
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                String name = entry.getProfile().getName();
                if (name != null && !name.isBlank() && !name.equalsIgnoreCase(mc.player.getName().getString())) {
                    list.add(name);
                }
            }
        }
        return list;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        AetherConfig cfg = AetherConfig.get();
        int accent = AetherHudRenderer.getAccentColor(cfg);
        int secondary = AetherHudRenderer.getSecondaryColor(cfg);

        int pad = 12;
        int topH = 30;
        int rightDockW = Math.min(200, Math.max(155, this.width / 4));
        int leftW = Math.max(240, this.width - pad * 3 - rightDockW);
        int bodyY = pad + topH + 8;
        int bodyH = Math.max(180, this.height - bodyY - pad);

        // Top floating header bar
        context.fill(pad, pad, this.width - pad, pad + topH, 0xEC090D16);
        context.fill(pad, pad, this.width - pad, pad + 2, accent);
        context.drawTextWithShadow(this.textRenderer, "§l" + AetherClient.CLIENT_NAME, pad + 10, pad + 7, accent);
        context.drawTextWithShadow(this.textRenderer, "§7v" + AetherClient.VERSION, pad + 10, pad + 18, 0xFF94A3B8);

        // Left module grid container
        context.fill(pad, bodyY, pad + leftW, bodyY + bodyH, 0xDC090D16);
        context.fill(pad, bodyY, pad + 2, bodyY + bodyH, accent);

        // Right dock container (Friends & Theme)
        int dockX = pad * 2 + leftW;
        context.fill(dockX, bodyY, dockX + rightDockW, bodyY + bodyH, 0xE6090D16);
        context.fill(dockX, bodyY, dockX + rightDockW, bodyY + 2, secondary);
        context.drawTextWithShadow(this.textRenderer, "§lДрузья (" + cfg.friends.size() + ")", dockX + 8, bodyY + 8, 0xFFF8FAFC);

        renderModuleCards(context, cfg, accent, pad, bodyY, leftW, bodyH);

        if (!statusLine.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, statusLine, dockX + 8, bodyY + bodyH - 58, 0xFF94A3B8);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderModuleCards(DrawContext context, AetherConfig cfg, int accent,
                                   int pad, int bodyY, int leftW, int bodyH) {
        List<ModuleEntry> modules = List.of(
                new ModuleEntry("ArmorDurability", "PvP", "Прочность брони под иконками", () -> cfg.armorDurability, v -> cfg.armorDurability = v),
                new ModuleEntry("HitParticles", "PvP", "Акцентные частицы при ударах", () -> cfg.hitParticles, v -> cfg.hitParticles = v),
                new ModuleEntry("TargetInfo", "PvP", "Визуальный блок информации о цели", () -> cfg.targetInfo, v -> cfg.targetInfo = v),
                new ModuleEntry("SwingVisual", "PvP", "Плавная анимация взмаха", () -> cfg.swingVisual, v -> cfg.swingVisual = v),
                new ModuleEntry("HitFlash", "PvP", "Подсветка попаданий", () -> cfg.hitFlash, v -> cfg.hitFlash = v),

                new ModuleEntry("CustomCrosshair", "Визуал", "Перекрестие по центру экрана", () -> cfg.customCrosshair, v -> cfg.customCrosshair = v),
                new ModuleEntry("Keystrokes", "Визуал", "Клавиши WASD, мышь и Space", () -> cfg.keystrokes, v -> cfg.keystrokes = v),
                new ModuleEntry("ArmorHud", "Визуал", "Индикатор брони у хотбара", () -> cfg.armorHud, v -> cfg.armorHud = v),
                new ModuleEntry("PotionTimers", "Визуал", "Таймеры эффектов зелий", () -> cfg.potionTimers, v -> cfg.potionTimers = v),
                new ModuleEntry("FpsCounter", "Визуал", "Счётчик FPS в углу экрана", () -> cfg.fpsCounter, v -> cfg.fpsCounter = v),
                new ModuleEntry("Watermark", "Визуал", "Бейдж Aether Visuals", () -> cfg.watermark, v -> cfg.watermark = v),

                new ModuleEntry("FriendsHighlight", "HUD и мир", "Выделяет друзей на радаре", () -> cfg.friendsHighlight, v -> cfg.friendsHighlight = v),
                new ModuleEntry("NearbyRadar", "HUD и мир", "Радар игроков рядом (64м)", () -> cfg.nearbyRadar, v -> cfg.nearbyRadar = v),
                new ModuleEntry("CoordsHud", "HUD и мир", "Координаты XYZ", () -> cfg.coordsHud, v -> cfg.coordsHud = v),
                new ModuleEntry("DirectionHud", "HUD и мир", "Направление взгляда", () -> cfg.directionHud, v -> cfg.directionHud = v),
                new ModuleEntry("BiomeHud", "HUD и мир", "Текущий биом", () -> cfg.biomeHud, v -> cfg.biomeHud = v),
                new ModuleEntry("WorldClock", "HUD и мир", "Игровые часы 24ч", () -> cfg.worldClock, v -> cfg.worldClock = v),
                new ModuleEntry("PingCounter", "HUD и мир", "Пинг до сервера", () -> cfg.pingCounter, v -> cfg.pingCounter = v),
                new ModuleEntry("ChromaAccent", "HUD и мир", "RGB перелив акцента", () -> cfg.chromaAccent, v -> cfg.chromaAccent = v)
        );

        String q = searchInput != null ? searchInput.getText().trim().toLowerCase() : "";
        List<ModuleEntry> filtered = new ArrayList<>();
        for (ModuleEntry m : modules) {
            boolean tabOk = switch (activeFilter) {
                case ALL -> true;
                case PVP -> "PvP".equals(m.category());
                case VISUALS -> "Визуал".equals(m.category());
                case MISC -> "HUD и мир".equals(m.category());
            };
            boolean qOk = q.isEmpty() || m.name().toLowerCase().contains(q) || m.hint().toLowerCase().contains(q);
            if (tabOk && qOk) filtered.add(m);
        }

        int gridCols = 2;
        int gap = 8;
        int cardW = (leftW - 20 - gap) / gridCols;
        int cardH = 38;
        int gridX = pad + 10;
        int gridY = bodyY + 10;
        int maxRows = Math.max(1, (bodyH - 18) / (cardH + gap));
        int maxItems = maxRows * gridCols;

        for (int i = 0; i < Math.min(filtered.size(), maxItems); i++) {
            ModuleEntry entry = filtered.get(i);
            int r = i / gridCols;
            int c = i % gridCols;
            int cx = gridX + c * (cardW + gap);
            int cy = gridY + r * (cardH + gap);

            boolean active = entry.getter().getAsBoolean();
            context.fill(cx, cy, cx + cardW, cy + cardH, 0xCC111827);
            context.fill(cx, cy, cx + cardW, cy + 1, active ? accent : 0xFF1F2937);

            context.drawTextWithShadow(this.textRenderer, "§l" + entry.name(), cx + 8, cy + 6, active ? 0xFFF8FAFC : 0xFFCBD5E1);
            context.drawTextWithShadow(this.textRenderer, "§8" + entry.category(), cx + 8, cy + 16, accent);
            String trimmed = this.textRenderer.trimToWidth(entry.hint(), cardW - 36);
            context.drawTextWithShadow(this.textRenderer, trimmed, cx + 8, cy + 26, 0xFF94A3B8);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
