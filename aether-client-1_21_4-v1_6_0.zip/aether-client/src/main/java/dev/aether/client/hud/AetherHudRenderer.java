package dev.aether.client.hud;

import dev.aether.client.AetherClient;
import dev.aether.client.config.AetherConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class AetherHudRenderer {

    public static final String[] THEME_NAMES = {
            "Aurora Cyan",
            "Hyper Violet",
            "Emerald Pulse",
            "Solar Amber",
            "Neon Rose",
            "Ice Slate"
    };

    public static final int[][] THEME_COLORS = {
            {0xFF38BDF8, 0xFF818CF8},
            {0xFFA855F7, 0xFFEC4899},
            {0xFF10B981, 0xFF34D399},
            {0xFFF59E0B, 0xFFF97316},
            {0xFFF43F5E, 0xFFA855F7},
            {0xFF67E8F9, 0xFF38BDF8}
    };

    public static int getAccentColor(AetherConfig cfg) {
        if (cfg.chromaAccent) {
            float hue = (System.currentTimeMillis() % 4200L) / 4200.0f;
            return 0xFF000000 | (Color.HSBtoRGB(hue, 0.72f, 0.98f) & 0x00FFFFFF);
        }
        int idx = Math.floorMod(cfg.themeIndex, THEME_COLORS.length);
        return THEME_COLORS[idx][0];
    }

    public static int getSecondaryColor(AetherConfig cfg) {
        int idx = Math.floorMod(cfg.themeIndex, THEME_COLORS.length);
        return THEME_COLORS[idx][1];
    }

    public static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        AetherConfig cfg = AetherConfig.get();

        if (!cfg.enabled || client.player == null || client.world == null) return;
        if (client.getDebugHud().shouldShowDebugHud() || client.options.hudHidden) return;

        TextRenderer tr = client.textRenderer;
        int accent = getAccentColor(cfg);
        int bgColor = (Math.clamp(cfg.panelOpacity, 0, 255) << 24) | 0x090D16;

        renderMainInfoBox(context, client, tr, cfg, accent, bgColor);

        if (cfg.keystrokes) {
            renderKeystrokes(context, client, tr, cfg, accent, bgColor);
        }

        if (cfg.armorHud || cfg.armorDurability) {
            renderArmorHud(context, client, tr, cfg, accent, bgColor);
        }

        if (cfg.potionTimers) {
            renderPotions(context, client, tr, accent, bgColor);
        }

        if (cfg.nearbyRadar) {
            renderNearbyRadar(context, client, tr, cfg, accent, bgColor);
        }

        if (cfg.customCrosshair && client.options.getPerspective().isFirstPerson()) {
            int cx = context.getScaledWindowWidth() / 2;
            int cy = context.getScaledWindowHeight() / 2;
            context.fill(cx - 6, cy, cx - 2, cy + 1, accent);
            context.fill(cx + 3, cy, cx + 7, cy + 1, accent);
            context.fill(cx, cy - 6, cx + 1, cy - 2, accent);
            context.fill(cx, cy + 3, cx + 1, cy + 7, accent);
            context.fill(cx, cy, cx + 1, cy + 1, 0xFFFFFFFF);
        }
    }

    private static void renderMainInfoBox(DrawContext context, MinecraftClient client, TextRenderer tr,
                                          AetherConfig cfg, int accent, int bgColor) {
        List<String> lines = new ArrayList<>();

        if (cfg.fpsCounter) {
            lines.add("FPS  §f" + client.getCurrentFps());
        }
        if (cfg.coordsHud) {
            BlockPos pos = client.player.getBlockPos();
            lines.add(String.format("XYZ  §f%d, %d, %d", pos.getX(), pos.getY(), pos.getZ()));
        }
        if (cfg.directionHud) {
            Direction dir = client.player.getHorizontalFacing();
            lines.add("DIR  §f" + dir.asString().toUpperCase());
        }
        if (cfg.biomeHud) {
            BlockPos pos = client.player.getBlockPos();
            Identifier biomeId = client.world.getRegistryManager()
                    .getOrThrow(RegistryKeys.BIOME)
                    .getId(client.world.getBiome(pos).value());
            String biomeName = biomeId != null ? formatId(biomeId.getPath()) : "Unknown";
            lines.add("BIO  §f" + biomeName);
        }
        if (cfg.pingCounter && client.getNetworkHandler() != null) {
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            int ping = entry != null ? entry.getLatency() : 0;
            lines.add("PNG  §f" + ping + "ms");
        }
        if (cfg.worldClock) {
            long timeOfDay = client.world.getTimeOfDay() % 24000L;
            long hours = ((timeOfDay / 1000L) + 6L) % 24L;
            long minutes = ((timeOfDay % 1000L) * 60L) / 1000L;
            lines.add(String.format("CLK  §f%02d:%02d", hours, minutes));
        }

        int x = cfg.hudX;
        int y = cfg.hudY;

        if (cfg.watermark) {
            String title = "§l" + AetherClient.CLIENT_NAME + " §r§7v" + AetherClient.VERSION;
            int w = tr.getWidth(title) + 14;
            context.fill(x, y, x + w, y + 17, bgColor);
            context.fill(x, y, x + 2, y + 17, accent);
            context.drawTextWithShadow(tr, title, x + 7, y + 4, accent);
            y += 20;
        }

        if (!lines.isEmpty()) {
            int maxWidth = 0;
            for (String line : lines) {
                maxWidth = Math.max(maxWidth, tr.getWidth(line));
            }
            int boxW = maxWidth + 14;
            int boxH = lines.size() * 11 + 7;

            context.fill(x, y, x + boxW, y + boxH, bgColor);
            context.fill(x, y, x + 2, y + boxH, accent);

            int textY = y + 4;
            for (String line : lines) {
                context.drawTextWithShadow(tr, line, x + 7, textY, 0xFF94A3B8);
                textY += 11;
            }
        }
    }

    private static void renderKeystrokes(DrawContext context, MinecraftClient client, TextRenderer tr,
                                         AetherConfig cfg, int accent, int bgColor) {
        int x = cfg.keystrokesX;
        int y = cfg.keystrokesY;
        int keySize = 21;
        int gap = 2;

        drawKeyBox(context, tr, "W", x + keySize + gap, y, keySize, keySize,
                client.options.forwardKey.isPressed(), accent, bgColor);

        int row2Y = y + keySize + gap;
        drawKeyBox(context, tr, "A", x, row2Y, keySize, keySize,
                client.options.leftKey.isPressed(), accent, bgColor);
        drawKeyBox(context, tr, "S", x + keySize + gap, row2Y, keySize, keySize,
                client.options.backKey.isPressed(), accent, bgColor);
        drawKeyBox(context, tr, "D", x + (keySize + gap) * 2, row2Y, keySize, keySize,
                client.options.rightKey.isPressed(), accent, bgColor);

        int row3Y = row2Y + keySize + gap;
        int mouseW = (keySize * 3 + gap) / 2;
        drawKeyBox(context, tr, "LMB", x, row3Y, mouseW, 16,
                client.options.attackKey.isPressed(), accent, bgColor);
        drawKeyBox(context, tr, "RMB", x + mouseW + gap, row3Y, mouseW, 16,
                client.options.useKey.isPressed(), accent, bgColor);

        int row4Y = row3Y + 18;
        int fullW = keySize * 3 + gap * 2;
        drawKeyBox(context, tr, "SPACE", x, row4Y, fullW, 14,
                client.options.jumpKey.isPressed(), accent, bgColor);
    }

    private static void drawKeyBox(DrawContext context, TextRenderer tr, String label,
                                   int x, int y, int w, int h, boolean pressed, int accent, int bgColor) {
        int fill = pressed ? ((accent & 0x00FFFFFF) | 0xDD000000) : bgColor;
        int textColor = pressed ? 0xFF090D16 : 0xFFE2E8F0;
        context.fill(x, y, x + w, y + h, fill);
        context.fill(x, y, x + w, y + 1, pressed ? 0xFFFFFFFF : ((accent & 0x00FFFFFF) | 0x33000000));
        int tw = tr.getWidth(label);
        context.drawText(tr, label, x + (w - tw) / 2, y + (h - 8) / 2, textColor, !pressed);
    }

    private static void renderArmorHud(DrawContext context, MinecraftClient client, TextRenderer tr,
                                       AetherConfig cfg, int accent, int bgColor) {
        int sw = context.getScaledWindowWidth();
        int sh = context.getScaledWindowHeight();
        int startX = sw / 2 + 12;
        int y = sh - 56;

        int offset = 0;
        for (int i = 3; i >= 0; i--) {
            ItemStack stack = client.player.getInventory().getArmorStack(i);
            if (!stack.isEmpty()) {
                int itemX = startX + offset * 22;
                context.fill(itemX - 1, y - 1, itemX + 17, y + 17, bgColor);
                context.fill(itemX - 1, y + 16, itemX + 17, y + 17, accent);
                context.drawItem(stack, itemX, y);
                context.drawStackOverlay(tr, stack, itemX, y);
                if (cfg.armorDurability && stack.isDamageable()) {
                    int rem = stack.getMaxDamage() - stack.getDamage();
                    context.drawTextWithShadow(tr, String.valueOf(rem), itemX + 1, y + 18, 0xFFCBD5E1);
                }
                offset++;
            }
        }
    }

    private static void renderPotions(DrawContext context, MinecraftClient client, TextRenderer tr,
                                      int accent, int bgColor) {
        var effects = client.player.getStatusEffects();
        if (effects.isEmpty()) return;

        int sw = context.getScaledWindowWidth();
        int y = 10;

        for (var effect : effects) {
            String name = effect.getEffectType().value().getName().getString();
            int amp = effect.getAmplifier() + 1;
            int sec = effect.getDuration() / 20;
            String time = effect.isInfinite() ? "∞" : String.format("%d:%02d", sec / 60, sec % 60);
            String label = name + (amp > 1 ? " " + amp : "") + " §7(" + time + ")";

            int w = tr.getWidth(label) + 12;
            int x = sw - w - 10;
            context.fill(x, y, x + w, y + 14, bgColor);
            context.fill(x + w - 2, y, x + w, y + 14, accent);
            context.drawTextWithShadow(tr, label, x + 5, y + 3, 0xFFE2E8F0);
            y += 16;
        }
    }

    private static void renderNearbyRadar(DrawContext context, MinecraftClient client, TextRenderer tr,
                                         AetherConfig cfg, int accent, int bgColor) {
        List<String> nearby = new ArrayList<>();
        for (PlayerEntity other : client.world.getPlayers()) {
            if (other == client.player) continue;
            double dist = client.player.distanceTo(other);
            if (dist <= 64.0) {
                String pName = other.getName().getString();
                boolean friend = cfg.friendsHighlight && AetherConfig.isFriend(pName);
                String tag = friend ? "§a[★] " : "§7• ";
                nearby.add(String.format("%s§f%s §8(%.0fm)", tag, pName, dist));
            }
        }
        if (nearby.isEmpty()) return;

        int sw = context.getScaledWindowWidth();
        int y = 10 + client.player.getStatusEffects().size() * 16 + (client.player.getStatusEffects().isEmpty() ? 0 : 6);

        int maxW = tr.getWidth("PLAYERS NEARBY") + 14;
        for (String s : nearby) {
            maxW = Math.max(maxW, tr.getWidth(s) + 14);
        }
        int boxH = nearby.size() * 11 + 18;
        int x = sw - maxW - 10;

        context.fill(x, y, x + maxW, y + boxH, bgColor);
        context.fill(x + maxW - 2, y, x + maxW, y + boxH, accent);
        context.drawTextWithShadow(tr, "§lPLAYERS NEARBY", x + 6, y + 4, accent);

        int lineY = y + 15;
        for (String line : nearby) {
            context.drawTextWithShadow(tr, line, x + 6, lineY, 0xFFE2E8F0);
            lineY += 11;
        }
    }

    private static String formatId(String raw) {
        String[] parts = raw.split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }
}
