package dev.aether.client.gui;

import dev.aether.client.AetherClient;
import dev.aether.client.config.AetherConfig;
import dev.aether.client.hud.AetherHudRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * Aether menu: sidebar navigation + card grid with animated toggles.
 * Everything is drawn manually (no vanilla buttons), supports mouse wheel and touch-drag scrolling.
 */
public class AetherModernStudioScreen extends Screen {

    // ---- colors ----
    private static final int C_WINDOW   = 0xF20B1020;
    private static final int C_SIDEBAR  = 0xFF080C17;
    private static final int C_BORDER   = 0xFF1B2440;
    private static final int C_CARD     = 0xFF121929;
    private static final int C_CARD_HOV = 0xFF171F35;
    private static final int C_TEXT     = 0xFFF1F5F9;
    private static final int C_MUTED    = 0xFF8A97B0;
    private static final int C_DIM      = 0xFF55627E;
    private static final int C_OFF      = 0xFF2B3550;

    private enum Page {
        ALL("Все функции", null),
        PVP("PvP", "PvP"),
        VISUALS("Визуал", "Визуал"),
        MISC("HUD и мир", "HUD и мир"),
        FRIENDS("Друзья", null),
        THEMES("Темы", null);

        final String label;
        final String category;

        Page(String label, String category) {
            this.label = label;
            this.category = category;
        }

        boolean isModules() {
            return this != FRIENDS && this != THEMES;
        }
    }

    private record ModuleEntry(String name, String category, String hint, BooleanSupplier getter, Consumer<Boolean> setter) {}

    private record Hit(int x1, int y1, int x2, int y2, Runnable action) {
        boolean contains(double mx, double my) {
            return mx >= x1 && mx < x2 && my >= y1 && my < y2;
        }
    }

    private record Row(int type, String text) {} // 0 = heading, 1 = friend, 2 = online player

    private final List<ModuleEntry> modules = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private final Map<String, Float> anim = new HashMap<>();

    private Page page = Page.ALL;
    private TextFieldWidget searchInput;
    private TextFieldWidget friendInput;

    // layout
    private int px, py, pw, ph, sbW, cx, cw, cy, ch, headerY;
    private int viewY, viewH; // scrollable region of the current page

    // scrolling
    private float scrollTarget, scrollCur;
    private int maxScroll;

    // press / drag tracking (touch friendly)
    private boolean pressing, dragged;
    private double pressX, pressY;

    // toast
    private String toast = "";
    private long toastUntil = 0L;

    public AetherModernStudioScreen() {
        super(Text.literal(AetherClient.CLIENT_NAME));
        AetherConfig cfg = AetherConfig.get();

        modules.add(new ModuleEntry("ArmorDurability", "PvP", "Прочность брони под иконками", () -> cfg.armorDurability, v -> cfg.armorDurability = v));
        modules.add(new ModuleEntry("HitParticles", "PvP", "Акцентные частицы при ударах", () -> cfg.hitParticles, v -> cfg.hitParticles = v));
        modules.add(new ModuleEntry("TargetInfo", "PvP", "Блок информации о цели", () -> cfg.targetInfo, v -> cfg.targetInfo = v));
        modules.add(new ModuleEntry("SwingVisual", "PvP", "Плавная анимация взмаха", () -> cfg.swingVisual, v -> cfg.swingVisual = v));
        modules.add(new ModuleEntry("HitFlash", "PvP", "Подсветка попаданий", () -> cfg.hitFlash, v -> cfg.hitFlash = v));

        modules.add(new ModuleEntry("CustomCrosshair", "Визуал", "Перекрестие по центру экрана", () -> cfg.customCrosshair, v -> cfg.customCrosshair = v));
        modules.add(new ModuleEntry("Keystrokes", "Визуал", "Клавиши WASD, мышь и Space", () -> cfg.keystrokes, v -> cfg.keystrokes = v));
        modules.add(new ModuleEntry("ArmorHud", "Визуал", "Индикатор брони у хотбара", () -> cfg.armorHud, v -> cfg.armorHud = v));
        modules.add(new ModuleEntry("PotionTimers", "Визуал", "Таймеры эффектов зелий", () -> cfg.potionTimers, v -> cfg.potionTimers = v));
        modules.add(new ModuleEntry("FpsCounter", "Визуал", "Счётчик FPS в углу экрана", () -> cfg.fpsCounter, v -> cfg.fpsCounter = v));
        modules.add(new ModuleEntry("Watermark", "Визуал", "Бейдж Aether Visuals", () -> cfg.watermark, v -> cfg.watermark = v));

        modules.add(new ModuleEntry("FriendsHighlight", "HUD и мир", "Выделяет друзей на радаре", () -> cfg.friendsHighlight, v -> cfg.friendsHighlight = v));
        modules.add(new ModuleEntry("NearbyRadar", "HUD и мир", "Радар игроков рядом (64м)", () -> cfg.nearbyRadar, v -> cfg.nearbyRadar = v));
        modules.add(new ModuleEntry("CoordsHud", "HUD и мир", "Координаты XYZ", () -> cfg.coordsHud, v -> cfg.coordsHud = v));
        modules.add(new ModuleEntry("DirectionHud", "HUD и мир", "Направление взгляда", () -> cfg.directionHud, v -> cfg.directionHud = v));
        modules.add(new ModuleEntry("BiomeHud", "HUD и мир", "Текущий биом", () -> cfg.biomeHud, v -> cfg.biomeHud = v));
        modules.add(new ModuleEntry("WorldClock", "HUD и мир", "Игровые часы 24ч", () -> cfg.worldClock, v -> cfg.worldClock = v));
        modules.add(new ModuleEntry("PingCounter", "HUD и мир", "Пинг до сервера", () -> cfg.pingCounter, v -> cfg.pingCounter = v));
        modules.add(new ModuleEntry("ChromaAccent", "HUD и мир", "RGB перелив акцента", () -> cfg.chromaAccent, v -> cfg.chromaAccent = v));
    }

    @Override
    protected void init() {
        String oldSearch = searchInput != null ? searchInput.getText() : "";
        String oldFriend = friendInput != null ? friendInput.getText() : "";
        this.clearChildren();

        searchInput = new TextFieldWidget(this.textRenderer, 0, 0, 100, 10, Text.literal("Поиск"));
        searchInput.setDrawsBackground(false);
        searchInput.setMaxLength(24);
        searchInput.setPlaceholder(Text.literal("Поиск..."));
        searchInput.setText(oldSearch);
        addDrawableChild(searchInput);

        friendInput = new TextFieldWidget(this.textRenderer, 0, 0, 100, 10, Text.literal("Ник"));
        friendInput.setDrawsBackground(false);
        friendInput.setMaxLength(16);
        friendInput.setPlaceholder(Text.literal("Ник друга..."));
        friendInput.setText(oldFriend);
        addDrawableChild(friendInput);

        computeLayout();
    }

    private void computeLayout() {
        pw = Math.min(this.width - 12, 500);
        ph = Math.min(this.height - 12, 300);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
        sbW = pw >= 380 ? 104 : 86;
        cx = px + sbW + 8;
        cw = pw - sbW - 16;
        headerY = py + 8;
        cy = py + 30;
        ch = ph - 38;
        viewY = cy;
        viewH = ch;
    }

    // ------------------------------------------------------------------ helpers

    private static void roundFill(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        if (x2 - x1 < 3 || y2 - y1 < 3) {
            c.fill(x1, y1, x2, y2, color);
            return;
        }
        c.fill(x1 + 1, y1, x2 - 1, y2, color);
        c.fill(x1, y1 + 1, x1 + 1, y2 - 1, color);
        c.fill(x2 - 1, y1 + 1, x2, y2 - 1, color);
    }

    private static void panel(DrawContext c, int x1, int y1, int x2, int y2, int border, int fill) {
        roundFill(c, x1, y1, x2, y2, border);
        roundFill(c, x1 + 1, y1 + 1, x2 - 1, y2 - 1, fill);
    }

    private static int withAlpha(int color, int alpha) {
        return (alpha << 24) | (color & 0xFFFFFF);
    }

    private static int lerpColor(int a, int b, float t) {
        int aa = a >>> 24, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = b >>> 24, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int ra = (int) (aa + (ba - aa) * t);
        int rr = (int) (ar + (br - ar) * t);
        int rg = (int) (ag + (bg - ag) * t);
        int rb = (int) (ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    private static float clamp(float v, float min, float max) {
        return v < min ? min : (v > max ? max : v);
    }

    private String fit(String s, int w) {
        if (w <= 0) return "";
        if (this.textRenderer.getWidth(s) <= w) return s;
        int dots = this.textRenderer.getWidth("...");
        return this.textRenderer.trimToWidth(s, Math.max(0, w - dots)) + "...";
    }

    private float animate(String key, boolean on) {
        float target = on ? 1f : 0f;
        float cur = anim.getOrDefault(key, target);
        cur += (target - cur) * 0.25f;
        if (Math.abs(target - cur) < 0.01f) cur = target;
        anim.put(key, cur);
        return cur;
    }

    private int categoryColor(String category, int accent, int secondary) {
        if ("PvP".equals(category)) return 0xFFF43F5E;
        if ("Визуал".equals(category)) return accent;
        return secondary;
    }

    private void showToast(String text) {
        toast = text;
        toastUntil = System.currentTimeMillis() + 1900L;
    }

    private void setPage(Page p) {
        page = p;
        scrollTarget = 0;
        scrollCur = 0;
        this.setFocused(null);
    }

    private void addHit(int x1, int y1, int x2, int y2, Runnable action) {
        hits.add(new Hit(x1, y1, x2, y2, action));
    }

    /** Hit that is clipped to the scrollable region (so hidden cards can't be clicked). */
    private void addViewHit(int x1, int y1, int x2, int y2, Runnable action) {
        int top = Math.max(y1, viewY);
        int bottom = Math.min(y2, viewY + viewH);
        if (top < bottom) hits.add(new Hit(x1, top, x2, bottom, action));
    }

    private boolean inView(double mx, double my) {
        return mx >= cx && mx < cx + cw + 6 && my >= viewY && my < viewY + viewH;
    }

    private void updateScroll(int contentH) {
        maxScroll = Math.max(0, contentH - viewH);
        scrollTarget = clamp(scrollTarget, 0, maxScroll);
        scrollCur += (scrollTarget - scrollCur) * 0.35f;
        if (Math.abs(scrollTarget - scrollCur) < 0.4f) scrollCur = scrollTarget;
        scrollCur = clamp(scrollCur, 0, maxScroll);
    }

    private void drawScrollbar(DrawContext ctx, int accent) {
        if (maxScroll <= 0) return;
        int x = px + pw - 5;
        ctx.fill(x, viewY, x + 2, viewY + viewH, 0x22FFFFFF);
        int thumbH = Math.max(16, viewH * viewH / (viewH + maxScroll));
        int thumbY = viewY + (int) ((viewH - thumbH) * (scrollCur / maxScroll));
        ctx.fill(x, thumbY, x + 2, thumbY + thumbH, withAlpha(accent, 0xCC));
    }

    private void drawToggle(DrawContext ctx, int x, int y, float a, int accent) {
        roundFill(ctx, x, y, x + 22, y + 11, lerpColor(C_OFF, accent, a));
        int kx = x + 1 + Math.round(a * 11f);
        roundFill(ctx, kx, y + 1, kx + 9, y + 10, lerpColor(0xFF8794B0, 0xFFFFFFFF, a));
    }

    private List<ModuleEntry> filteredModules() {
        String q = searchInput != null ? searchInput.getText().trim().toLowerCase(Locale.ROOT) : "";
        List<ModuleEntry> out = new ArrayList<>();
        for (ModuleEntry m : modules) {
            boolean tabOk = page.category == null || page.category.equals(m.category());
            boolean qOk = q.isEmpty()
                    || m.name().toLowerCase(Locale.ROOT).contains(q)
                    || m.hint().toLowerCase(Locale.ROOT).contains(q);
            if (tabOk && qOk) out.add(m);
        }
        return out;
    }

    private List<String> getOnlinePlayers() {
        List<String> list = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null && mc.player != null) {
            String self = mc.player.getName().getString();
            for (PlayerListEntry entry : mc.getNetworkHandler().getPlayerList()) {
                String name = entry.getProfile().getName();
                if (name != null && !name.isBlank() && !name.equalsIgnoreCase(self)) {
                    list.add(name);
                }
            }
        }
        return list;
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        this.renderBackground(ctx, mx, my, delta);
        computeLayout();
        hits.clear();

        AetherConfig cfg = AetherConfig.get();
        int accent = AetherHudRenderer.getAccentColor(cfg);
        int secondary = AetherHudRenderer.getSecondaryColor(cfg);

        // window
        panel(ctx, px - 1, py - 1, px + pw + 1, py + ph + 1, withAlpha(accent, 0x55), C_WINDOW);

        renderSidebar(ctx, mx, my, cfg, accent, secondary);
        renderHeader(ctx, accent);

        searchInput.setVisible(page.isModules());
        friendInput.setVisible(page == Page.FRIENDS);

        switch (page) {
            case FRIENDS -> renderFriends(ctx, mx, my, delta, cfg, accent);
            case THEMES -> renderThemes(ctx, mx, my, cfg, accent, secondary);
            default -> renderModules(ctx, mx, my, accent, secondary);
        }

        if (page.isModules()) {
            searchInput.render(ctx, mx, my, delta);
        }

        // toast
        long now = System.currentTimeMillis();
        if (now < toastUntil && !toast.isEmpty()) {
            int tw = this.textRenderer.getWidth(toast) + 18;
            int tx = cx + (cw - tw) / 2;
            int ty = py + ph - 26;
            panel(ctx, tx, ty, tx + tw, ty + 16, withAlpha(accent, 0xAA), 0xF00A0F1B);
            ctx.drawTextWithShadow(this.textRenderer, toast, tx + 9, ty + 4, C_TEXT);
        }
    }

    private void renderSidebar(DrawContext ctx, int mx, int my, AetherConfig cfg, int accent, int secondary) {
        // sidebar background (rounded on the left, flat on the right)
        roundFill(ctx, px, py, px + sbW, py + ph, C_SIDEBAR);
        ctx.fill(px + sbW - 3, py + 1, px + sbW, py + ph - 1, C_SIDEBAR);
        ctx.fill(px + sbW, py + 4, px + sbW + 1, py + ph - 4, C_BORDER);

        int sx = px + 6;
        int sw = sbW - 12;

        // logo
        roundFill(ctx, sx, py + 8, sx + 15, py + 23, accent);
        roundFill(ctx, sx + 4, py + 12, sx + 11, py + 19, C_SIDEBAR);
        ctx.fill(sx + 6, py + 14, sx + 9, py + 17, secondary);
        ctx.drawTextWithShadow(this.textRenderer, "§lAETHER", sx + 20, py + 8, C_TEXT);
        ctx.drawTextWithShadow(this.textRenderer, "v" + AetherClient.VERSION, sx + 20, py + 17, C_DIM);

        int ny = py + 31;
        boolean labels = ph >= 190;

        if (labels) {
            ctx.drawTextWithShadow(this.textRenderer, "ФУНКЦИИ", sx + 4, ny, C_DIM);
            ny += 11;
        }
        for (Page p : new Page[]{Page.ALL, Page.PVP, Page.VISUALS, Page.MISC}) {
            drawNavItem(ctx, p, p.label, sx, ny, sw, 16, mx, my, accent);
            ny += 17;
        }

        if (labels) {
            ny += 3;
            ctx.drawTextWithShadow(this.textRenderer, "ПРОЧЕЕ", sx + 4, ny, C_DIM);
            ny += 11;
        }
        drawNavItem(ctx, Page.FRIENDS, "Друзья (" + cfg.friends.size() + ")", sx, ny, sw, 16, mx, my, accent);
        ny += 17;
        drawNavItem(ctx, Page.THEMES, "Темы", sx, ny, sw, 16, mx, my, accent);

        // reset HUD at the bottom
        int ry = py + ph - 22;
        boolean hover = mx >= sx && mx < sx + sw && my >= ry && my < ry + 16;
        panel(ctx, sx, ry, sx + sw, ry + 16, hover ? withAlpha(accent, 0x99) : C_BORDER, hover ? C_CARD_HOV : C_CARD);
        String reset = fit("Сброс HUD", sw - 8);
        ctx.drawTextWithShadow(this.textRenderer, reset, sx + (sw - this.textRenderer.getWidth(reset)) / 2, ry + 4, hover ? C_TEXT : C_MUTED);
        addHit(sx, ry, sx + sw, ry + 16, () -> {
            cfg.hudX = 10;
            cfg.hudY = 10;
            cfg.keystrokesX = 10;
            cfg.keystrokesY = 148;
            AetherConfig.save();
            showToast("§aПозиции HUD сброшены");
        });
    }

    private void drawNavItem(DrawContext ctx, Page p, String label, int x, int y, int w, int h, int mx, int my, int accent) {
        boolean sel = page == p;
        boolean hover = mx >= x && mx < x + w && my >= y && my < y + h;
        if (sel) {
            roundFill(ctx, x, y, x + w, y + h, withAlpha(accent, 0x30));
            ctx.fill(x, y + 3, x + 2, y + h - 3, accent);
        } else if (hover) {
            roundFill(ctx, x, y, x + w, y + h, 0x14FFFFFF);
        }
        int dotY = y + h / 2 - 2;
        roundFill(ctx, x + 7, dotY, x + 11, dotY + 4, sel ? accent : C_DIM);
        ctx.drawTextWithShadow(this.textRenderer, fit(label, w - 20), x + 16, y + (h - 8) / 2, sel ? C_TEXT : C_MUTED);
        addHit(x, y, x + w, y + h, () -> setPage(p));
    }

    private void renderHeader(DrawContext ctx, int accent) {
        ctx.drawTextWithShadow(this.textRenderer, "§l" + page.label, cx, headerY + 4, C_TEXT);

        if (page.isModules()) {
            int count = filteredModules().size();
            int titleW = this.textRenderer.getWidth("§l" + page.label);
            ctx.drawTextWithShadow(this.textRenderer, String.valueOf(count), cx + titleW + 6, headerY + 4, C_DIM);

            int bw = Math.min(130, Math.max(70, cw - titleW - 40));
            int bx = cx + cw - bw;
            panel(ctx, bx, headerY, bx + bw, headerY + 16, searchInput.isFocused() ? withAlpha(accent, 0xAA) : C_BORDER, 0xFF0C1220);
            searchInput.setX(bx + 6);
            searchInput.setY(headerY + 4);
            searchInput.setWidth(bw - 12);
            addHit(bx, headerY, bx + bw, headerY + 16, () -> this.setFocused(searchInput));
        }
    }

    // ---- modules page ----

    private void renderModules(DrawContext ctx, int mx, int my, int accent, int secondary) {
        viewY = cy;
        viewH = ch;

        List<ModuleEntry> list = filteredModules();
        int gap = 6;
        int cols = Math.max(1, (cw + gap) / (150 + gap));
        int cardW = (cw - gap * (cols - 1)) / cols;
        int cardH = 36;
        int rows = (list.size() + cols - 1) / cols;
        int contentH = rows == 0 ? 0 : rows * (cardH + gap) - gap;
        updateScroll(contentH);

        int off = Math.round(scrollCur);
        ctx.enableScissor(cx, viewY, cx + cw, viewY + viewH);
        for (int i = 0; i < list.size(); i++) {
            final ModuleEntry entry = list.get(i);
            int x = cx + (i % cols) * (cardW + gap);
            int y = viewY + (i / cols) * (cardH + gap) - off;
            if (y + cardH < viewY || y > viewY + viewH) continue;

            boolean hover = mx >= x && mx < x + cardW
                    && my >= Math.max(y, viewY) && my < Math.min(y + cardH, viewY + viewH);
            drawModuleCard(ctx, entry, x, y, cardW, cardH, hover, accent, secondary);
            addViewHit(x, y, x + cardW, y + cardH, () -> {
                boolean now = !entry.getter().getAsBoolean();
                entry.setter().accept(now);
                AetherConfig.save();
                showToast(entry.name() + ": " + (now ? "§aВКЛ" : "§7ВЫКЛ"));
            });
        }
        ctx.disableScissor();

        if (list.isEmpty()) {
            String msg = "Ничего не найдено";
            ctx.drawTextWithShadow(this.textRenderer, msg, cx + (cw - this.textRenderer.getWidth(msg)) / 2, viewY + 30, C_DIM);
        }
        drawScrollbar(ctx, accent);
    }

    private void drawModuleCard(DrawContext ctx, ModuleEntry e, int x, int y, int w, int h,
                                boolean hover, int accent, int secondary) {
        boolean on = e.getter().getAsBoolean();
        float a = animate(e.name(), on);

        panel(ctx, x, y, x + w, y + h, hover ? withAlpha(accent, 0x88) : C_BORDER, hover ? C_CARD_HOV : C_CARD);
        if (a > 0.01f) {
            ctx.fill(x + 1, y + 4, x + 3, y + h - 4, withAlpha(accent, (int) (255 * a)));
        }

        int catColor = categoryColor(e.category(), accent, secondary);
        int ix = x + 9;
        int iy = y + (h - 18) / 2;
        roundFill(ctx, ix, iy, ix + 18, iy + 18, withAlpha(catColor, on ? 0x55 : 0x22));
        String letter = e.name().substring(0, 1);
        int lw = this.textRenderer.getWidth(letter);
        ctx.drawTextWithShadow(this.textRenderer, letter, ix + (18 - lw) / 2, iy + 5, on ? catColor : C_DIM);

        int tx = x + w - 22 - 8;
        drawToggle(ctx, tx, y + (h - 11) / 2, a, accent);

        int textX = ix + 18 + 7;
        int textW = tx - 6 - textX;
        ctx.drawTextWithShadow(this.textRenderer, fit(e.name(), textW), textX, y + 8, on ? C_TEXT : 0xFFCBD5E1);
        ctx.drawTextWithShadow(this.textRenderer, fit(e.hint(), textW), textX, y + 20, C_DIM);
    }

    // ---- friends page ----

    private void renderFriends(DrawContext ctx, int mx, int my, float delta, AetherConfig cfg, int accent) {
        int bh = 18;
        int btnW = Math.min(70, Math.max(52, cw / 4));
        int bw = cw - btnW - 6;

        // input box
        panel(ctx, cx, cy, cx + bw, cy + bh, friendInput.isFocused() ? withAlpha(accent, 0xAA) : C_BORDER, 0xFF0C1220);
        friendInput.setX(cx + 6);
        friendInput.setY(cy + 5);
        friendInput.setWidth(bw - 12);
        friendInput.render(ctx, mx, my, delta);
        addHit(cx, cy, cx + bw, cy + bh, () -> this.setFocused(friendInput));

        // add button
        int bx = cx + bw + 6;
        boolean addHover = mx >= bx && mx < bx + btnW && my >= cy && my < cy + bh;
        panel(ctx, bx, cy, bx + btnW, cy + bh, withAlpha(accent, 0xCC), addHover ? withAlpha(accent, 0x66) : withAlpha(accent, 0x38));
        String addLabel = "Добавить";
        ctx.drawTextWithShadow(this.textRenderer, fit(addLabel, btnW - 6),
                bx + (btnW - this.textRenderer.getWidth(fit(addLabel, btnW - 6))) / 2, cy + 5, C_TEXT);
        addHit(bx, cy, bx + btnW, cy + bh, () -> {
            String nick = friendInput.getText().trim();
            if (AetherConfig.addFriend(nick)) {
                friendInput.setText("");
                showToast("§a+ §f" + nick);
            } else {
                showToast("§cНик пуст или уже в списке");
            }
        });

        // rows
        viewY = cy + bh + 8;
        viewH = ch - (bh + 8);

        List<Row> rows = new ArrayList<>();
        if (cfg.friends.isEmpty()) {
            rows.add(new Row(0, "Друзья пока не добавлены"));
        } else {
            rows.add(new Row(0, "ВАШИ ДРУЗЬЯ"));
            for (String f : cfg.friends) rows.add(new Row(1, f));
        }
        List<String> online = new ArrayList<>();
        for (String name : getOnlinePlayers()) {
            if (!AetherConfig.isFriend(name)) online.add(name);
        }
        if (!online.isEmpty()) {
            rows.add(new Row(0, "СЕЙЧАС НА СЕРВЕРЕ"));
            for (String name : online) rows.add(new Row(2, name));
        }

        int headingH = 13;
        int rowH = 18;
        int rowGap = 3;
        int contentH = 0;
        for (Row r : rows) contentH += (r.type() == 0 ? headingH : rowH + rowGap);
        updateScroll(contentH);

        int off = Math.round(scrollCur);
        int y = viewY - off;
        ctx.enableScissor(cx, viewY, cx + cw, viewY + viewH);
        for (Row r : rows) {
            if (r.type() == 0) {
                if (y + headingH >= viewY && y <= viewY + viewH) {
                    ctx.drawTextWithShadow(this.textRenderer, r.text(), cx + 2, y + 2, C_DIM);
                }
                y += headingH;
                continue;
            }
            if (y + rowH >= viewY && y <= viewY + viewH) {
                final String name = r.text();
                boolean friend = r.type() == 1;
                boolean hover = mx >= cx && mx < cx + cw && my >= Math.max(y, viewY) && my < Math.min(y + rowH, viewY + viewH);
                panel(ctx, cx, y, cx + cw, y + rowH, C_BORDER, hover ? C_CARD_HOV : C_CARD);

                ctx.drawTextWithShadow(this.textRenderer, friend ? "★" : "○", cx + 8, y + 5, friend ? accent : C_DIM);
                ctx.drawTextWithShadow(this.textRenderer, fit(name, cw - 52), cx + 22, y + 5, friend ? C_TEXT : C_MUTED);

                int bx2 = cx + cw - 18;
                roundFill(ctx, bx2, y + 2, bx2 + 14, y + rowH - 2, friend ? 0xFF3A1824 : withAlpha(accent, 0x44));
                String sign = friend ? "×" : "+";
                ctx.drawTextWithShadow(this.textRenderer, sign,
                        bx2 + (14 - this.textRenderer.getWidth(sign)) / 2, y + 5, friend ? 0xFFF87171 : C_TEXT);

                if (friend) {
                    addViewHit(bx2 - 2, y, cx + cw, y + rowH, () -> {
                        AetherConfig.removeFriend(name);
                        showToast("§eУдалён: §f" + name);
                    });
                } else {
                    addViewHit(cx, y, cx + cw, y + rowH, () -> {
                        AetherConfig.addFriend(name);
                        showToast("§a+ §f" + name);
                    });
                }
            }
            y += rowH + rowGap;
        }
        ctx.disableScissor();
        drawScrollbar(ctx, accent);
    }

    // ---- themes page ----

    private void renderThemes(DrawContext ctx, int mx, int my, AetherConfig cfg, int accent, int secondary) {
        viewY = cy;
        viewH = ch;

        int count = AetherHudRenderer.THEME_NAMES.length + 1; // + chroma
        int gap = 6;
        int cols = Math.max(1, (cw + gap) / (110 + gap));
        int cardW = (cw - gap * (cols - 1)) / cols;
        int cardH = 42;
        int rows = (count + cols - 1) / cols;
        updateScroll(rows * (cardH + gap) - gap);

        int off = Math.round(scrollCur);
        ctx.enableScissor(cx, viewY, cx + cw, viewY + viewH);
        for (int i = 0; i < count; i++) {
            int x = cx + (i % cols) * (cardW + gap);
            int y = viewY + (i / cols) * (cardH + gap) - off;
            if (y + cardH < viewY || y > viewY + viewH) continue;

            boolean chroma = i == AetherHudRenderer.THEME_NAMES.length;
            boolean selected = chroma ? cfg.chromaAccent : (!cfg.chromaAccent && cfg.themeIndex == i);
            boolean hover = mx >= x && mx < x + cardW
                    && my >= Math.max(y, viewY) && my < Math.min(y + cardH, viewY + viewH);

            panel(ctx, x, y, x + cardW, y + cardH,
                    selected ? accent : (hover ? withAlpha(accent, 0x88) : C_BORDER),
                    hover ? C_CARD_HOV : C_CARD);

            // gradient swatch
            int sx = x + 8;
            int sw = cardW - 16;
            int sy = y + 8;
            for (int px2 = 0; px2 < sw; px2 += 2) {
                float t = px2 / (float) Math.max(1, sw - 1);
                int color;
                if (chroma) {
                    color = 0xFF000000 | (java.awt.Color.HSBtoRGB(t, 0.7f, 1f) & 0xFFFFFF);
                } else {
                    int[] pair = AetherHudRenderer.THEME_COLORS[i];
                    color = lerpColor(pair[0], pair[1], t);
                }
                ctx.fill(sx + px2, sy, Math.min(sx + px2 + 2, sx + sw), sy + 8, color);
            }

            String name = chroma ? "Chroma (RGB)" : AetherHudRenderer.THEME_NAMES[i];
            ctx.drawTextWithShadow(this.textRenderer, fit(name, cardW - 16 - (selected ? 10 : 0)), x + 8, y + 24, selected ? C_TEXT : C_MUTED);
            if (selected) {
                roundFill(ctx, x + cardW - 14, y + 25, x + cardW - 8, y + 31, accent);
            }

            final int idx = i;
            addViewHit(x, y, x + cardW, y + cardH, () -> {
                if (chroma) {
                    cfg.chromaAccent = !cfg.chromaAccent;
                    showToast("Chroma: " + (cfg.chromaAccent ? "§aВКЛ" : "§7ВЫКЛ"));
                } else {
                    cfg.themeIndex = idx;
                    cfg.chromaAccent = false;
                    showToast("Тема: §f" + AetherHudRenderer.THEME_NAMES[idx]);
                }
                AetherConfig.save();
            });
        }
        ctx.disableScissor();
        drawScrollbar(ctx, accent);
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) {
            pressing = false;
            return true;
        }
        if (button == 0) {
            pressing = true;
            dragged = false;
            pressX = mx;
            pressY = my;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (pressing) {
            if (!dragged && Math.abs(my - pressY) > 4 && inView(pressX, pressY)) {
                dragged = true;
            }
            if (dragged) {
                scrollTarget = clamp(scrollTarget - (float) dy, 0, maxScroll);
                scrollCur = clamp(scrollCur - (float) dy, 0, maxScroll);
                return true;
            }
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (pressing && button == 0) {
            pressing = false;
            if (!dragged) {
                for (Hit h : hits) {
                    if (h.contains(pressX, pressY) && h.contains(mx, my)) {
                        h.action().run();
                        break;
                    }
                }
            }
            dragged = false;
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontalAmount, double verticalAmount) {
        if (inView(mx, my)) {
            scrollTarget = clamp(scrollTarget - (float) verticalAmount * 18f, 0, maxScroll);
            return true;
        }
        return super.mouseScrolled(mx, my, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
