package dev.aether.client;

import dev.aether.client.config.AetherConfig;
import dev.aether.client.gui.AetherModernStudioScreen;
import dev.aether.client.hud.AetherHudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class AetherClient implements ClientModInitializer {
    public static final String MOD_ID = "aether";
    public static final String CLIENT_NAME = "Aether Visuals";
    public static final String VERSION = "1.6.0";

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        AetherConfig.load();

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.aether.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.aether.general"
        ));

        HudRenderCallback.EVENT.register(AetherHudRenderer::render);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new AetherModernStudioScreen());
                }
            }
        });
    }
}
