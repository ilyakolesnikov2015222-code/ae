package dev.aether.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class AetherConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("aether-client.json");

    public boolean enabled = true;

    // PvP / Combat visuals
    public boolean armorDurability = true;
    public boolean hitParticles = true;
    public boolean targetInfo = false;
    public boolean swingVisual = true;
    public boolean hitFlash = true;

    // Visuals / HUD modules
    public boolean fullBright = true;
    public boolean customCrosshair = true;
    public boolean keystrokes = true;
    public boolean armorHud = true;
    public boolean potionTimers = true;
    public boolean fpsCounter = true;
    public boolean watermark = true;
    public boolean directionHud = true;
    public boolean biomeHud = true;

    // Misc / World & Friends modules
    public boolean friendsHighlight = true;
    public boolean nearbyRadar = true;
    public boolean worldClock = true;
    public boolean pingCounter = true;
    public boolean coordsHud = true;
    public boolean compactPanels = false;
    public boolean chromaAccent = false;

    // Theme & Palette
    public int themeIndex = 0; // 0 = Aurora Cyan, 1 = Hyper Violet, 2 = Emerald Pulse, 3 = Solar Amber, 4 = Neon Rose, 5 = Ice Slate
    public int panelOpacity = 195;

    public int hudX = 10;
    public int hudY = 10;
    public int keystrokesX = 10;
    public int keystrokesY = 148;

    public List<String> friends = new ArrayList<>();

    private static AetherConfig instance;

    public static AetherConfig get() {
        if (instance == null) {
            load();
        }
        if (instance.friends == null) {
            instance.friends = new ArrayList<>();
        }
        return instance;
    }

    public static boolean isFriend(String name) {
        if (name == null || name.isBlank()) return false;
        for (String f : get().friends) {
            if (f.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    public static boolean addFriend(String name) {
        if (name == null) return false;
        String clean = name.trim();
        if (clean.isEmpty() || isFriend(clean)) return false;
        get().friends.add(clean);
        save();
        return true;
    }

    public static boolean removeFriend(String name) {
        if (name == null) return false;
        boolean removed = get().friends.removeIf(f -> f.equalsIgnoreCase(name.trim()));
        if (removed) save();
        return removed;
    }

    public static void load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
                AetherConfig loaded = GSON.fromJson(reader, AetherConfig.class);
                instance = loaded != null ? loaded : new AetherConfig();
            } catch (Exception e) {
                instance = new AetherConfig();
            }
        } else {
            instance = new AetherConfig();
            save();
        }
        if (instance.friends == null) {
            instance.friends = new ArrayList<>();
        }
    }

    public static void save() {
        if (instance == null) return;
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(instance, writer);
            }
        } catch (IOException ignored) {
        }
    }
}
